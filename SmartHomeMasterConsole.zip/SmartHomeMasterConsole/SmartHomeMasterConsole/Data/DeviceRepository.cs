using System.Data.Common;
using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Data;

public sealed class DeviceRepository : SqliteRepositoryBase<Device>
{
    public DeviceRepository(SqliteConnectionFactory connectionFactory)
        : base(connectionFactory)
    {
    }

    protected override string SelectSql =>
        "SELECT Id, RoomId, Model, Power, Type, Accuracy, LoadCapacity, PassportJson FROM Devices";

    protected override Device Map(DbDataReader reader) => DeviceFactory.Create(
        type: reader.GetString(4),
        id: reader.GetInt(0),
        roomId: reader.GetInt(1),
        model: reader.GetString(2),
        power: reader.GetReal(3),
        accuracy: reader.GetNullableReal(5),
        loadCapacity: reader.GetNullableReal(6),
        passport: PassportSerializer.Deserialize(reader.GetNullableString(7)));

    protected override DbCommand CreateInsertCommand(DbConnection connection, DbTransaction? transaction, Device entity) =>
        BuildInsertCommand(connection, transaction, entity);

    protected override void SetGeneratedId(Device entity, int id) => entity.AssignId(id);

    internal static DbCommand BuildInsertCommand(DbConnection connection, DbTransaction? transaction, Device device) =>
        connection.NewCommand(
                "INSERT INTO Devices (RoomId, Model, Power, Type, Accuracy, LoadCapacity, PassportJson) " +
                "VALUES (@roomId, @model, @power, @type, @accuracy, @loadCapacity, @passport);", transaction)
            .WithParameter("@roomId", device.RoomId)
            .WithParameter("@model", device.Model)
            .WithParameter("@power", device.Power)
            .WithParameter("@type", device.Type)
            .WithParameter("@accuracy", (device as SmartSensor)?.Accuracy)
            .WithParameter("@loadCapacity", (device as SmartActuator)?.LoadCapacity)
            .WithParameter("@passport", PassportSerializer.Serialize(device.Passport));
}
