using System.Data.Common;
using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Data;

public sealed class TelemetryRepository : SqliteRepositoryBase<TelemetryLog>
{
    public TelemetryRepository(SqliteConnectionFactory connectionFactory)
        : base(connectionFactory)
    {
    }

    protected override string SelectSql => "SELECT Id, DeviceId, Reading, Timestamp FROM TelemetryLogs";

    protected override TelemetryLog Map(DbDataReader reader) => new(
        reader.GetInt(0),
        reader.GetInt(1),
        reader.GetReal(2),
        TelemetryLog.ParseTimestamp(reader.GetString(3)));

    protected override DbCommand CreateInsertCommand(DbConnection connection, DbTransaction? transaction, TelemetryLog entity) =>
        BuildInsertCommand(connection, transaction, entity);

    protected override void SetGeneratedId(TelemetryLog entity, int id) => entity.AssignId(id);

    public async Task AddRangeAsync(IReadOnlyCollection<TelemetryLog> logs, CancellationToken cancellationToken = default)
    {
        if (logs.Count == 0) return;

        using DbConnection connection = await ConnectionFactory.OpenAsync(cancellationToken).ConfigureAwait(false);
        using DbTransaction transaction = connection.BeginTransaction();
        foreach (TelemetryLog log in logs)
        {
            using (DbCommand insert = BuildInsertCommand(connection, transaction, log))
                await insert.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
            log.AssignId(await connection.LastInsertRowIdAsync(transaction, cancellationToken).ConfigureAwait(false));
        }

        transaction.Commit();
    }

    internal static DbCommand BuildInsertCommand(DbConnection connection, DbTransaction? transaction, TelemetryLog log) =>
        connection.NewCommand(
                "INSERT INTO TelemetryLogs (DeviceId, Reading, Timestamp) VALUES (@deviceId, @reading, @timestamp);", transaction)
            .WithParameter("@deviceId", log.DeviceId)
            .WithParameter("@reading", log.Reading)
            .WithParameter("@timestamp", log.TimestampText);
}
