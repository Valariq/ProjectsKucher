using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Data;

public sealed class SmartHomeDataStore
{
    private readonly SqliteConnectionFactory _factory;

    public SmartHomeDataStore(string databasePath)
    {
        _factory = new SqliteConnectionFactory(databasePath);
        Rooms = new RoomRepository(_factory);
        Devices = new DeviceRepository(_factory);
        Telemetry = new TelemetryRepository(_factory);
    }

    public string DatabasePath => _factory.DatabasePath;

    public RoomRepository Rooms { get; }
    public DeviceRepository Devices { get; }
    public TelemetryRepository Telemetry { get; }

    public List<Room> RoomList { get; private set; } = new();
    public List<Device> DeviceList { get; private set; } = new();
    public List<TelemetryLog> LogList { get; private set; } = new();

    public bool WasSeeded { get; private set; }

    public async Task LoadAsync(CancellationToken cancellationToken = default)
    {
        WasSeeded = await Task.Run(() => DatabaseInitializer.EnsureCreatedAsync(_factory, cancellationToken), cancellationToken);

        Task<List<Room>> roomsTask = Task.Run(() => Rooms.GetAllAsync(cancellationToken), cancellationToken);
        Task<List<Device>> devicesTask = Task.Run(() => Devices.GetAllAsync(cancellationToken), cancellationToken);
        Task<List<TelemetryLog>> logsTask = Task.Run(() => Telemetry.GetAllAsync(cancellationToken), cancellationToken);

        await Task.WhenAll(roomsTask, devicesTask, logsTask);

        RoomList = await roomsTask;
        DeviceList = await devicesTask;
        LogList = await logsTask;
        RestoreLastReadings();
    }

    public async Task ReloadTelemetryAsync(CancellationToken cancellationToken = default)
    {
        LogList = await Task.Run(() => Telemetry.GetAllAsync(cancellationToken), cancellationToken);
    }

    public async Task AddDeviceAsync(Device device, CancellationToken cancellationToken = default)
    {
        await Task.Run(() => Devices.AddAsync(device, cancellationToken), cancellationToken);
        DeviceList.Add(device);
    }

    public string RoomTitleOf(int roomId) =>
        RoomList.FirstOrDefault(room => room.Id == roomId)?.Title ?? $"комната #{roomId}";

    private void RestoreLastReadings()
    {
        Dictionary<int, double> lastReadings = LogList
            .GroupBy(log => log.DeviceId)
            .ToDictionary(
                group => group.Key,
                group => group.OrderByDescending(log => log.Timestamp).ThenByDescending(log => log.Id).First().Reading);

        foreach (Device device in DeviceList)
        {
            if (lastReadings.TryGetValue(device.Id, out double reading))
                device.RestoreLastReading(reading);
        }
    }
}
