using System.Data.Common;
using SmartHomeMasterConsole.Interfaces;

namespace SmartHomeMasterConsole.Data;

public abstract class SqliteRepositoryBase<T> : IAsyncRepository<T> where T : class
{
    protected SqliteRepositoryBase(SqliteConnectionFactory connectionFactory)
    {
        ConnectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
    }

    protected SqliteConnectionFactory ConnectionFactory { get; }

    protected abstract string SelectSql { get; }

    protected abstract T Map(DbDataReader reader);

    protected abstract DbCommand CreateInsertCommand(DbConnection connection, DbTransaction? transaction, T entity);

    protected abstract void SetGeneratedId(T entity, int id);

    public T GetById(int id)
    {
        using DbConnection connection = ConnectionFactory.Open();
        using DbCommand command = connection.NewCommand(SelectSql + " WHERE Id = @id;").WithParameter("@id", id);
        using DbDataReader reader = command.ExecuteReader();
        if (reader.Read()) return Map(reader);
        throw new KeyNotFoundException($"{typeof(T).Name} с Id = {id} не найден.");
    }

    public List<T> GetAll()
    {
        using DbConnection connection = ConnectionFactory.Open();
        using DbCommand command = connection.NewCommand(SelectSql + " ORDER BY Id;");
        using DbDataReader reader = command.ExecuteReader();
        var result = new List<T>();
        while (reader.Read()) result.Add(Map(reader));
        return result;
    }

    public void Add(T entity)
    {
        if (entity is null) throw new ArgumentNullException(nameof(entity));
        using DbConnection connection = ConnectionFactory.Open();
        using (DbCommand insert = CreateInsertCommand(connection, null, entity))
            insert.ExecuteNonQuery();
        SetGeneratedId(entity, connection.LastInsertRowId(null));
    }

    public async Task<T?> FindByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        using DbConnection connection = await ConnectionFactory.OpenAsync(cancellationToken).ConfigureAwait(false);
        using DbCommand command = connection.NewCommand(SelectSql + " WHERE Id = @id;").WithParameter("@id", id);
        using DbDataReader reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        return await reader.ReadAsync(cancellationToken).ConfigureAwait(false) ? Map(reader) : null;
    }

    public async Task<List<T>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        using DbConnection connection = await ConnectionFactory.OpenAsync(cancellationToken).ConfigureAwait(false);
        using DbCommand command = connection.NewCommand(SelectSql + " ORDER BY Id;");
        using DbDataReader reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        var result = new List<T>();
        while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
            result.Add(Map(reader));
        return result;
    }

    public async Task AddAsync(T entity, CancellationToken cancellationToken = default)
    {
        if (entity is null) throw new ArgumentNullException(nameof(entity));
        using DbConnection connection = await ConnectionFactory.OpenAsync(cancellationToken).ConfigureAwait(false);
        using (DbCommand insert = CreateInsertCommand(connection, null, entity))
            await insert.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        SetGeneratedId(entity, await connection.LastInsertRowIdAsync(null, cancellationToken).ConfigureAwait(false));
    }
}
