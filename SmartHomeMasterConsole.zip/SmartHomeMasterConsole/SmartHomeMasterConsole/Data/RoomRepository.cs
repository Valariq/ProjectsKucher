using System.Data.Common;
using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Data;

public sealed class RoomRepository : SqliteRepositoryBase<Room>
{
    public RoomRepository(SqliteConnectionFactory connectionFactory)
        : base(connectionFactory)
    {
    }

    protected override string SelectSql => "SELECT Id, Title, Floor FROM Rooms";

    protected override Room Map(DbDataReader reader) =>
        new(reader.GetInt(0), reader.GetString(1), reader.GetInt(2));

    protected override DbCommand CreateInsertCommand(DbConnection connection, DbTransaction? transaction, Room entity) =>
        BuildInsertCommand(connection, transaction, entity);

    protected override void SetGeneratedId(Room entity, int id) => entity.AssignId(id);

    internal static DbCommand BuildInsertCommand(DbConnection connection, DbTransaction? transaction, Room room) =>
        connection.NewCommand("INSERT INTO Rooms (Title, Floor) VALUES (@title, @floor);", transaction)
            .WithParameter("@title", room.Title)
            .WithParameter("@floor", room.Floor);
}
