using System.Data.Common;
using SmartHomeMasterConsole.Models;
using SmartHomeMasterConsole.Services;

namespace SmartHomeMasterConsole.Data;

internal static class DemoDataSeeder
{
    private const string S = SmartSensor.TypeName;
    private const string A = SmartActuator.TypeName;

    private static readonly (string Title, int Floor)[] Rooms =
    {
        ("Гараж", 0), ("Котельная", 0),
        ("Прихожая", 1), ("Гостиная", 1), ("Кухня", 1), ("Кладовая", 1),
        ("Спальня", 2), ("Детская", 2), ("Кабинет", 2), ("Ванная", 2),
    };

    private static readonly DeviceSeed[] Devices =
    {
        new("Прихожая", "Philips Hue White A60", A, 9, 10),
        new("Прихожая", "Nuki Smart Lock 3", A, 4, 6, WithTelemetry: false),
        new("Прихожая", "Philips Hue Motion", S, 0.8, 1.5, "лк", 500),

        new("Гостиная", "Aqara T1 Temperature", S, 0.5, 0.3, "°C", 28),
        new("Гостиная", "Netatmo CO2 Monitor", S, 2.5, 3.0, "ppm", 1000),
        new("Гостиная", "Philips Hue White A60", A, 9, 10),
        new("Гостиная", "LG DualCool AC", A, 1450, 1800),
        new("Гостиная", "Somfy Blind Motor", A, 60, 80, WithTelemetry: false),

        new("Кухня", "Aqara T1 Temperature", S, 0.5, 0.4, "°C", 30),
        new("Кухня", "Xiaomi Gas Detector", S, 1.5, 1.0, "% НКПР", 10),
        new("Кухня", "Redmond SkyKettle", A, 2200, 2400),
        new("Кухня", "Shelly Plug S", A, 2000, 2500),
        new("Кухня", "Philips Hue White A60", A, 9, 10),

        new("Спальня", "Aqara T1 Temperature", S, 0.5, 0.3, "°C", 26),
        new("Спальня", "Philips Hue White A60", A, 9, 10),
        new("Спальня", "Xiaomi Humidifier 2", A, 25, 30),
        new("Спальня", "Ballu Heater BEC", A, 1500, 2000),

        new("Детская", "Aqara T1 Temperature", S, 0.5, 0.3, "°C", 26),
        new("Детская", "Netatmo CO2 Monitor", S, 2.5, 1.5, "ppm", 900),
        new("Детская", "Philips Hue White A60", A, 9, 10),
        new("Детская", "Xiaomi Air Purifier 4", A, 30, 40),
        new("Детская", "Qingping Air Monitor", S, 2.0, 2.5, "мкг/м³", 35),

        new("Кабинет", "Shelly Plug S", A, 350, 2500),
        new("Кабинет", "Philips Hue White A60", A, 9, 10),
        new("Кабинет", "Netatmo CO2 Monitor", S, 2.5, 1.5, "ppm", 1000),
        new("Кабинет", "Qingping Air Monitor", S, 2.0, 1.0, "мкг/м³", 35),

        new("Ванная", "Aqara Humidity Sensor", S, 0.4, 2.0, "%", 75),
        new("Ванная", "Aqara Water Leak", S, 0.3, 0.5, "мм", 1),
        new("Ванная", "Electrolux Towel Rail", A, 120, 150),

        new("Гараж", "Shelly Plus 1PM", A, 550, 700),
        new("Гараж", "Xiaomi Gas Detector", S, 1.5, 5.0, "% НКПР", 10),
        new("Гараж", "Wallbox Pulsar Plus", A, 7400, 7400),

        new("Котельная", "Aqara T1 Temperature", S, 0.5, 0.3, "°C", 35),
        new("Котельная", "Fibaro Smoke Sensor", S, 0.2, 2.5, "мг/м³", 50, WithTelemetry: false),
        new("Котельная", "ЭВАН Warmos-IV", A, 9000, 10000),
    };

    public static void Seed(DbConnection connection)
    {
        var random = new Random(2026);
        DateTime now = DateTime.Now;

        using DbTransaction transaction = connection.BeginTransaction();

        var roomIds = new Dictionary<string, int>();
        foreach (var (title, floor) in Rooms)
        {
            var room = new Room(0, title, floor);
            using (DbCommand insert = RoomRepository.BuildInsertCommand(connection, transaction, room))
                insert.ExecuteNonQuery();
            roomIds[title] = connection.LastInsertRowId(transaction);
        }

        int index = 0;
        foreach (DeviceSeed seed in Devices)
        {
            index++;
            DevicePassport passport = CreatePassport(seed, index, now, random);
            Device device = DeviceFactory.Create(seed.Type, 0, roomIds[seed.Room], seed.Model, seed.Power,
                accuracy: seed.Type == S ? seed.Param : null,
                loadCapacity: seed.Type == A ? seed.Param : null,
                passport);

            using (DbCommand insert = DeviceRepository.BuildInsertCommand(connection, transaction, device))
                insert.ExecuteNonQuery();
            device.AssignId(connection.LastInsertRowId(transaction));

            if (!seed.WithTelemetry) continue;

            for (int step = 7; step >= 0; step--)
            {
                double raw = TelemetrySimulator.NextRawReading(device, random);
                double reading = Math.Round(passport.Calibration.Apply(raw), 2);
                DateTime timestamp = now.AddHours(-6 * step).AddMinutes(-random.Next(1, 50));
                using DbCommand insertLog = TelemetryRepository.BuildInsertCommand(connection, transaction,
                    new TelemetryLog(device.Id, reading, timestamp));
                insertLog.ExecuteNonQuery();
            }
        }

        transaction.Commit();
    }

    private static DevicePassport CreatePassport(DeviceSeed seed, int index, DateTime now, Random random)
    {
        bool isSensor = seed.Type == S;
        string manufacturer = seed.Model.Split(' ')[0];
        DateTime commissioned = now.Date.AddDays(-random.Next(120, 900));
        DateTime calibrated = now.Date.AddDays(-random.Next(10, 110));

        return new DevicePassport
        {
            SerialNumber = $"{manufacturer.ToUpperInvariant().Substring(0, Math.Min(4, manufacturer.Length))}-{commissioned:yyMM}-{index:D4}",
            Manufacturer = manufacturer,
            CommissionedAt = commissioned,
            Unit = isSensor ? seed.Unit : "Вт",
            SafeLimit = isSensor ? seed.SafeLimit : 0,
            Calibration = new CalibrationData
            {
                Factor = isSensor ? Math.Round(1 + (random.NextDouble() - 0.5) * 0.04, 3) : 1.0,
                Offset = isSensor ? Math.Round((random.NextDouble() - 0.5) * 0.4, 2) : 0.0,
                CalibratedAt = calibrated,
            },
            ServiceHistory =
            {
                $"{commissioned:dd.MM.yyyy} — ввод в эксплуатацию",
                $"{calibrated:dd.MM.yyyy} — {(isSensor ? "поверка и калибровка" : "плановое ТО")}",
            },
        };
    }

    private sealed record DeviceSeed(
        string Room, string Model, string Type, double Power, double Param,
        string Unit = "", double SafeLimit = 0, bool WithTelemetry = true);
}
