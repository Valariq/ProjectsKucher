using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Data;

internal static class PassportSerializer
{
    private static readonly JsonSerializerOptions Options = new()
    {
        Encoder = JavaScriptEncoder.Create(
            UnicodeRanges.BasicLatin, UnicodeRanges.Latin1Supplement, UnicodeRanges.Cyrillic, UnicodeRanges.GeneralPunctuation),
    };

    public static string Serialize(DevicePassport passport) => JsonSerializer.Serialize(passport, Options);

    public static DevicePassport? Deserialize(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return null;
        try
        {
            return JsonSerializer.Deserialize<DevicePassport>(json, Options);
        }
        catch (JsonException)
        {
            return new DevicePassport { SerialNumber = "ПАСПОРТ ПОВРЕЖДЁН" };
        }
    }
}
