using System.Data.Common;
using System.Globalization;

namespace SmartHomeMasterConsole.Data;

internal static class DbExtensions
{
    public static DbCommand NewCommand(this DbConnection connection, string sql, DbTransaction? transaction = null)
    {
        DbCommand command = connection.CreateCommand();
        command.CommandText = sql;
        command.Transaction = transaction;
        return command;
    }

    public static DbCommand WithParameter(this DbCommand command, string name, object? value)
    {
        DbParameter parameter = command.CreateParameter();
        parameter.ParameterName = name;
        parameter.Value = value ?? DBNull.Value;
        command.Parameters.Add(parameter);
        return command;
    }

    public static int ExecuteNonQuery(this DbConnection connection, string sql)
    {
        using DbCommand command = connection.NewCommand(sql);
        return command.ExecuteNonQuery();
    }

    public static async Task<int> ExecuteNonQueryAsync(this DbConnection connection, string sql, CancellationToken cancellationToken = default)
    {
        using DbCommand command = connection.NewCommand(sql);
        return await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public static int LastInsertRowId(this DbConnection connection, DbTransaction? transaction)
    {
        using DbCommand command = connection.NewCommand("SELECT last_insert_rowid();", transaction);
        return Convert.ToInt32(command.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    public static async Task<int> LastInsertRowIdAsync(this DbConnection connection, DbTransaction? transaction, CancellationToken cancellationToken = default)
    {
        using DbCommand command = connection.NewCommand("SELECT last_insert_rowid();", transaction);
        object? value = await command.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false);
        return Convert.ToInt32(value, CultureInfo.InvariantCulture);
    }

    public static int GetInt(this DbDataReader reader, int ordinal) =>
        Convert.ToInt32(reader.GetValue(ordinal), CultureInfo.InvariantCulture);

    public static double GetReal(this DbDataReader reader, int ordinal) =>
        Convert.ToDouble(reader.GetValue(ordinal), CultureInfo.InvariantCulture);

    public static double? GetNullableReal(this DbDataReader reader, int ordinal) =>
        reader.IsDBNull(ordinal) ? null : reader.GetReal(ordinal);

    public static string? GetNullableString(this DbDataReader reader, int ordinal) =>
        reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
}
