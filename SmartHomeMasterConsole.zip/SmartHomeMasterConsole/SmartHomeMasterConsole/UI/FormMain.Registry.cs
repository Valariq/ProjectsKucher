using System.Text;
using SmartHomeMasterConsole.Dto;
using SmartHomeMasterConsole.Interfaces;
using SmartHomeMasterConsole.Models;
using SmartHomeMasterConsole.Services;

namespace SmartHomeMasterConsole.UI;

public partial class FormMain
{
    private readonly DataGridView _gridDevices = Ui.Grid("gridDevices");
    private readonly ComboBox _cmbNewRoom = Ui.DropDown("cmbNewRoom");
    private readonly ComboBox _cmbNewType = Ui.DropDown("cmbNewType");
    private readonly TextBox _txtNewModel = new() { Name = "txtNewModel" };
    private readonly NumericUpDown _numNewPower = Ui.Number("numNewPower", 0, 100000, 1, 60);
    private readonly Label _lblNewExtra = Ui.Label("Точность, ±%");
    private readonly NumericUpDown _numNewExtra = Ui.Number("numNewExtra", 0, 100000, 2, 0.5m);
    private readonly TextBox _txtNewUnit = new() { Name = "txtNewUnit", Text = "°C" };
    private readonly NumericUpDown _numNewSafeLimit = Ui.Number("numNewSafeLimit", 0, 100000, 1, 30);
    private readonly TextBox _txtNewSerial = new() { Name = "txtNewSerial" };
    private readonly CheckBox _chkSaveCopy = new() { Name = "chkSaveCopy", Text = "Сохранять копию в БД как новый прибор", Checked = true, AutoSize = true };
    private readonly NumericUpDown _numGetById = Ui.Number("numGetById", 1, int.MaxValue, 0, 1, 80);
    private readonly TextBox _txtRegistryOutput = Ui.OutputBox("txtRegistryOutput");

    private bool _nextSortAscending = true;

    private TabPage BuildRegistryTab()
    {
        _gridDevices.MultiSelect = true;
        _gridDevices.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex >= 0) BtnShowStatus_Click(this, EventArgs.Empty);
        };

        _cmbNewType.Items.AddRange(new object[] { SmartSensor.TypeName, SmartActuator.TypeName });
        _cmbNewType.SelectedIndex = 0;
        _cmbNewType.SelectedIndexChanged += (_, _) => UpdateNewDeviceFields();

        Button btnAdd = Ui.Button("Добавить в БД — IRepository<Device>.Add", "btnAddDevice");
        btnAdd.Click += BtnAddDevice_Click;

        TableLayoutPanel newDeviceForm = Ui.FormGrid(2,
            (Ui.Label("Комната"), _cmbNewRoom),
            (Ui.Label("Тип"), _cmbNewType),
            (Ui.Label("Модель"), _txtNewModel),
            (Ui.Label("Мощность, Вт"), _numNewPower),
            (_lblNewExtra, _numNewExtra),
            (Ui.Label("Серийный №"), _txtNewSerial),
            (Ui.Label("Ед. измерения"), _txtNewUnit),
            (Ui.Label("Порог тревоги"), _numNewSafeLimit));
        newDeviceForm.RowCount++;
        newDeviceForm.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        btnAdd.Anchor = AnchorStyles.Right;
        newDeviceForm.Controls.Add(btnAdd, 3, newDeviceForm.RowCount - 1);

        Button btnSort = Ui.Button("Сортировать по мощности — IComparable<Device>", "btnSortByPower");
        Button btnCompare = Ui.Button("Сравнить 2 выделенных — CompareTo / Equals", "btnCompareTwo");
        Button btnStatus = Ui.Button("ToString() / GetStatus() — override", "btnShowStatus");
        Button btnShadowing = Ui.Button("Shadowing: new против override", "btnShadowing");
        Button btnDeepCopy = Ui.Button("Deep Copy выделенного — ICloneable", "btnDeepCopy");
        Button btnExport = Ui.Button("Экспорт CSV — явный IExportable", "btnExport");
        Button btnToggle = Ui.Button("Вкл./выкл. выделенные — событие", "btnToggle");
        Button btnGetById = Ui.Button("GetById(Id) — IRepository<Device>", "btnGetById");
        Button btnReload = Ui.Button("Перезагрузить из SQLite (async)", "btnReload");

        btnSort.Click += BtnSortByPower_Click;
        btnCompare.Click += BtnCompareTwo_Click;
        btnStatus.Click += BtnShowStatus_Click;
        btnShadowing.Click += BtnShadowing_Click;
        btnDeepCopy.Click += BtnDeepCopy_Click;
        btnExport.Click += BtnExport_Click;
        btnToggle.Click += BtnToggle_Click;
        btnGetById.Click += BtnGetById_Click;
        btnReload.Click += async (_, _) => await ReloadAllAsync();

        FlowLayoutPanel operations = Ui.SidePanel(
            Ui.Section("ООП и интерфейсы"),
            btnSort, btnCompare, btnStatus, btnShadowing, btnExport,
            Ui.Section("Клонирование"),
            btnDeepCopy, _chkSaveCopy,
            Ui.Section("Состояние и события"),
            btnToggle,
            Ui.Section("Репозиторий"),
            Ui.Inline(Ui.Label("Id"), _numGetById), btnGetById, btnReload);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 3 };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Ui.SidePanelWidth));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 205));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 42));

        root.Controls.Add(Ui.Group("Реестр приборов — DataGridView (Ctrl / Shift — выделить несколько; двойной щелчок — статус)", _gridDevices), 0, 0);
        root.Controls.Add(Ui.Group("Новый прибор — валидация в конструкторе класса", newDeviceForm), 0, 1);
        root.Controls.Add(Ui.Group("Результат", _txtRegistryOutput), 0, 2);
        root.Controls.Add(operations, 1, 0);
        root.SetRowSpan(operations, 3);

        TabPage page = Ui.Page("Реестр приборов (ООП && Generics)", "tabRegistry");
        page.Controls.Add(root);
        UpdateNewDeviceFields();
        WriteOutput(_txtRegistryOutput, "Подсказка",
            "Выделите прибор в таблице и нажмите кнопку справа. Для сравнения выделите два прибора (Ctrl + щелчок).");
        return page;
    }

    private void RefreshRegistryGrid(params int[] selectIds)
    {
        int[] keep = selectIds.Length > 0 ? selectIds : SelectedDevices().Select(d => d.Id).ToArray();

        _gridDevices.DataSource = _store.DeviceList
            .Select(device => new DeviceGridRow(device, _store.RoomTitleOf(device.RoomId)))
            .ToList();

        _gridDevices.ClearSelection();
        foreach (DataGridViewRow row in _gridDevices.Rows)
        {
            if (row.DataBoundItem is DeviceGridRow item && keep.Contains(item.Id))
                row.Selected = true;
        }
    }

    private List<Device> SelectedDevices() => _gridDevices.SelectedRows
        .Cast<DataGridViewRow>()
        .OrderBy(row => row.Index)
        .Select(row => row.DataBoundItem)
        .OfType<DeviceGridRow>()
        .Select(item => item.Source)
        .ToList();

    private Device? SelectedDevice()
    {
        Device? device = SelectedDevices().FirstOrDefault()
                         ?? (_gridDevices.CurrentRow?.DataBoundItem as DeviceGridRow)?.Source;
        if (device is null) Warn("Выберите прибор в таблице реестра.");
        return device;
    }

    private void UpdateNewDeviceFields()
    {
        bool isSensor = Equals(_cmbNewType.SelectedItem, SmartSensor.TypeName);
        _lblNewExtra.Text = isSensor ? "Точность, ±%" : "Макс. нагрузка, Вт";
        _numNewExtra.DecimalPlaces = isSensor ? 2 : 0;
        _numNewExtra.Value = isSensor ? 0.5m : Math.Min(Math.Max(_numNewPower.Value * 1.25m, 1m), _numNewExtra.Maximum);
        _txtNewUnit.Enabled = isSensor;
        _numNewSafeLimit.Enabled = isSensor;
        _txtNewUnit.Text = isSensor ? (_txtNewUnit.Text == "Вт" ? "°C" : _txtNewUnit.Text) : "Вт";
    }

    private async void BtnAddDevice_Click(object? sender, EventArgs e)
    {
        if (_cmbNewRoom.SelectedItem is not Room room)
        {
            Warn("Выберите комнату.");
            return;
        }

        bool isSensor = Equals(_cmbNewType.SelectedItem, SmartSensor.TypeName);
        string model = _txtNewModel.Text;
        var passport = new DevicePassport
        {
            SerialNumber = string.IsNullOrWhiteSpace(_txtNewSerial.Text) ? $"NEW-{DateTime.Now:yyMMdd-HHmmss}" : _txtNewSerial.Text.Trim(),
            Manufacturer = model.Trim().Split(' ')[0],
            CommissionedAt = DateTime.Today,
            Unit = isSensor ? _txtNewUnit.Text.Trim() : "Вт",
            SafeLimit = isSensor ? (double)_numNewSafeLimit.Value : 0,
            Calibration = new CalibrationData { Factor = 1, Offset = 0, CalibratedAt = DateTime.Today },
            ServiceHistory = { $"{DateTime.Today:dd.MM.yyyy} — добавлен через SmartHome Master Console" },
        };

        try
        {
            Device device = DeviceFactory.Create(
                isSensor ? SmartSensor.TypeName : SmartActuator.TypeName, 0, room.Id, model, (double)_numNewPower.Value,
                accuracy: isSensor ? (double)_numNewExtra.Value : null,
                loadCapacity: isSensor ? null : (double)_numNewExtra.Value,
                passport);

            SetBusy(true, "Сохранение в SQLite...");
            await _store.AddDeviceAsync(device);
            ApplyEventSubscription();
            RefreshAllViews();
            RefreshRegistryGrid(device.Id);

            WriteOutput(_txtRegistryOutput, "IRepository<Device>.Add (асинхронно через AddAsync)",
                $"Сохранено в таблицу Devices: {device}\n" +
                $"Id = {device.Id} назначила база (last_insert_rowid) — снаружи класса Id изменить нельзя: private set.");
            Log($"Добавлен прибор {device.Title}", LogKind.Success);
            _txtNewModel.Clear();
            _txtNewSerial.Clear();
        }
        catch (ArgumentException ex)
        {
            Warn("Объект не создан — сработала проверка в конструкторе:\n" + ex.Message);
        }
        catch (Exception ex)
        {
            ShowError("Не удалось сохранить прибор", ex);
        }
        finally
        {
            SetBusy(false);
        }
    }

    private void BtnSortByPower_Click(object? sender, EventArgs e)
    {
        List<Device> devices = _store.DeviceList;
        if (devices.Count == 0) return;

        bool ascending = _nextSortAscending;
        if (ascending)
            devices.Sort();
        else
            devices.Sort((a, b) => b.CompareTo(a));
        _nextSortAscending = !ascending;

        bool isSorted = devices
            .Zip(devices.Skip(1), (a, b) => ascending ? a.CompareTo(b) <= 0 : a.CompareTo(b) >= 0)
            .All(ok => ok);
        RefreshRegistryGrid();

        var text = new StringBuilder()
            .AppendLine(ascending
                ? "devices.Sort() — по возрастанию Power через IComparable<Device>.CompareTo"
                : "devices.Sort((a, b) => b.CompareTo(a)) — по убыванию (делегат Comparison<Device>)")
            .AppendLine($"Порядок проверен попарно через CompareTo: {(isSorted ? "OK" : "НАРУШЕН")}")
            .AppendLine($"Первый:    {devices[0]}")
            .AppendLine($"Последний: {devices[devices.Count - 1]}")
            .AppendLine($"CompareTo(null) = {devices[0].CompareTo(null)} — любой объект «больше» null")
            .AppendLine("При равной мощности порядок определяет Id — сортировка детерминирована.")
            .AppendLine("Следующее нажатие отсортирует в обратном порядке.");
        WriteOutput(_txtRegistryOutput, "IComparable<Device>", text.ToString());
    }

    private void BtnCompareTwo_Click(object? sender, EventArgs e)
    {
        List<Device> selected = SelectedDevices();
        if (selected.Count != 2)
        {
            Warn("Выделите в таблице ровно два прибора (Ctrl + щелчок).");
            return;
        }

        Device a = selected[0];
        Device b = selected[1];
        Device aClone = a.DeepClone();
        int comparison = a.CompareTo(b);
        string relation = comparison < 0 ? "меньше" : comparison > 0 ? "больше" : "равна";

        var text = new StringBuilder()
            .AppendLine($"A: {a}")
            .AppendLine($"B: {b}")
            .AppendLine()
            .AppendLine($"A.CompareTo(B) = {comparison}  -> мощность A {relation} мощности B")
            .AppendLine($"A.Equals(B)    = {a.Equals(b)}  (сравнение по Id и Model)")
            .AppendLine($"Хеш A = {a.GetHashCode()}, хеш B = {b.GetHashCode()}")
            .AppendLine()
            .AppendLine("Копия A (DeepClone):")
            .AppendLine($"A.Equals(копия) = {a.Equals(aClone)};  ReferenceEquals(A, копия) = {ReferenceEquals(a, aClone)};  хеши равны: {a.GetHashCode() == aClone.GetHashCode()}")
            .AppendLine("=> Equals и GetHashCode согласованы: равные объекты дают одинаковый хеш (это важно для Dictionary, HashSet, Union, Except).");
        WriteOutput(_txtRegistryOutput, "IComparable<Device> и переопределённый Equals", text.ToString());
    }

    private void BtnShowStatus_Click(object? sender, EventArgs e)
    {
        Device? device = SelectedDevice();
        if (device is null) return;

        var text = new StringBuilder()
            .AppendLine("ToString() — override System.Object:")
            .AppendLine("  " + device)
            .AppendLine($"GetStatus() — virtual в Device, override в {device.GetType().Name}:")
            .AppendLine("  " + device.GetStatus())
            .AppendLine($"CalculatePowerConsumption() — abstract: {device.CalculatePowerConsumption():F2} Вт")
            .AppendLine($"GetHashCode() = {device.GetHashCode()}")
            .AppendLine()
            .AppendLine("Паспорт (вложенный объект): " + device.Passport)
            .AppendLine("История обслуживания: " + string.Join(" | ", device.Passport.ServiceHistory));
        WriteOutput(_txtRegistryOutput, "Переопределённые члены", text.ToString());
    }

    private void BtnShadowing_Click(object? sender, EventArgs e)
    {
        SmartSensor? sensor = SelectedDevices().OfType<SmartSensor>().FirstOrDefault()
                              ?? _store.DeviceList.OfType<SmartSensor>().FirstOrDefault();
        if (sensor is null)
        {
            Warn("В реестре нет ни одного датчика.");
            return;
        }

        Device asBase = sensor;
        var text = new StringBuilder()
            .AppendLine($"Объект {sensor.Title}, тип объекта — {sensor.GetType().Name}")
            .AppendLine()
            .AppendLine("1) GetDescription() скрыт в SmartSensor ключевым словом new:")
            .AppendLine($"   SmartSensor s = ...; s.GetDescription()  -> {sensor.GetDescription()}")
            .AppendLine($"   Device d = s;        d.GetDescription()  -> {asBase.GetDescription()}")
            .AppendLine("   Версия выбирается по типу ПЕРЕМЕННОЙ при компиляции (статическое связывание).")
            .AppendLine()
            .AppendLine("2) GetStatus() переопределён через override:")
            .AppendLine($"   s.GetStatus() -> {sensor.GetStatus()}")
            .AppendLine($"   d.GetStatus() -> {asBase.GetStatus()}")
            .AppendLine("   Версия выбирается по типу ОБЪЕКТА во время выполнения (виртуальный вызов).");
        WriteOutput(_txtRegistryOutput, "Shadowing (new) против override", text.ToString());
    }

    private async void BtnDeepCopy_Click(object? sender, EventArgs e)
    {
        Device? original = SelectedDevice();
        if (original is null) return;

        var clone = (Device)original.Clone();
        DeepCopyReport report = DeepCopyVerifier.Verify(original, clone);
        string body = report.Text;

        if (_chkSaveCopy.Checked)
        {
            try
            {
                Device record = clone.CloneAsNew();
                await _store.AddDeviceAsync(record);
                ApplyEventSubscription();
                RefreshAllViews();
                RefreshRegistryGrid(original.Id, record.Id);
                body += $"\nКопия сохранена в SQLite как прибор #{record.Id} (S/N {record.Passport.SerialNumber}); " +
                        $"оригинал #{original.Id} сохранил S/N {original.Passport.SerialNumber}.";
            }
            catch (Exception ex)
            {
                ShowError("Не удалось сохранить копию", ex);
            }
        }

        WriteOutput(_txtRegistryOutput, "ICloneable — глубокое копирование (Deep Copy)", body);
        Log($"Deep Copy {original.Title}: {(report.IsDeepCopy ? "глубокая копия подтверждена" : "ОШИБКА — копия поверхностная")}",
            report.IsDeepCopy ? LogKind.Success : LogKind.Critical);
    }

    private void BtnExport_Click(object? sender, EventArgs e)
    {
        List<string> lines = _store.DeviceList
            .Cast<IExportable>()
            .Select(exportable => exportable.GetExportData())
            .Prepend(Device.ExportHeader)
            .ToList();

        var text = new StringBuilder()
            .AppendLine("Вызов возможен только через интерфейс: ((IExportable)device).GetExportData()")
            .AppendLine("Первые строки CSV:");
        foreach (string line in lines.Take(6)) text.AppendLine("  " + line);

        using var dialog = new SaveFileDialog
        {
            Title = "Экспорт реестра приборов",
            Filter = "CSV (*.csv)|*.csv",
            FileName = $"smart_home_devices_{DateTime.Now:yyyyMMdd_HHmm}.csv",
        };
        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            File.WriteAllLines(dialog.FileName, lines, new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
            text.AppendLine().AppendLine($"Сохранено строк: {lines.Count - 1}, файл: {dialog.FileName}");
        }
        WriteOutput(_txtRegistryOutput, "IExportable — явная реализация интерфейса", text.ToString());
    }

    private void BtnToggle_Click(object? sender, EventArgs e)
    {
        List<Device> selected = SelectedDevices();
        if (selected.Count == 0)
        {
            Warn("Выделите один или несколько приборов.");
            return;
        }

        foreach (Device device in selected)
            device.Toggle();

        RefreshRegistryGrid(selected.Select(d => d.Id).ToArray());
        RefreshAnalytics();
        RefreshPage();

        string note = _chkSubscribe.Checked
            ? "Событие StatusChanged записано в журнал на вкладке «Асинхронный опрос & Events»."
            : "Подписка выключена: у события нет обработчиков, и StatusChanged?.Invoke(...) безопасно ничего не сделал.";
        WriteOutput(_txtRegistryOutput, "Изменение состояния -> событие StatusChanged",
            string.Join("\n", selected.Select(d => d.GetStatus())) + "\n\n" + note);
    }

    private async void BtnGetById_Click(object? sender, EventArgs e)
    {
        int id = (int)_numGetById.Value;
        try
        {
            Device loaded = await Task.Run(() => _store.Devices.GetById(id));
            Device? inRegistry = _store.DeviceList.FirstOrDefault(d => d.Id == id);

            WriteOutput(_txtRegistryOutput, $"IRepository<Device>.GetById({id})",
                $"Из SQLite создан НОВЫЙ объект: {loaded}\n" +
                $"Фактический тип: {loaded.GetType().Name} (выбран фабрикой по столбцу Type)\n" +
                $"Equals(объект реестра) = {inRegistry?.Equals(loaded).ToString() ?? "в реестре нет"};  " +
                $"ReferenceEquals = {ReferenceEquals(inRegistry, loaded)}");
        }
        catch (KeyNotFoundException ex)
        {
            WriteOutput(_txtRegistryOutput, $"IRepository<Device>.GetById({id})", ex.Message);
        }
        catch (Exception ex)
        {
            ShowError("Ошибка чтения из SQLite", ex);
        }
    }
}
