using System.Text;
using SmartHomeMasterConsole.Dto;
using SmartHomeMasterConsole.Models;
using SmartHomeMasterConsole.Services;

namespace SmartHomeMasterConsole.UI;

public partial class FormMain
{
    private readonly NumericUpDown _numMinPower = Ui.Number("numMinPower", 0, 100000, 0, 0, 90);
    private readonly ComboBox _cmbFilterType = Ui.DropDown("cmbFilterType", 170);
    private readonly ComboBox _cmbFilterFloor = Ui.DropDown("cmbFilterFloor", 110);
    private readonly TextBox _txtSearch = new() { Name = "txtSearch", Width = 170 };
    private readonly CheckBox _chkOnlyCritical = new() { Name = "chkOnlyCritical", Text = "Только критичные", AutoSize = true, Margin = new Padding(10, 6, 3, 3) };
    private readonly Button _btnDeferred = Ui.Button("Отложенное выполнение: IEnumerable и ToList()", "btnDeferred");
    private readonly Label _lblFilterCount = new() { Name = "lblFilterCount", AutoSize = true, Margin = new Padding(10, 7, 3, 3), ForeColor = SystemColors.GrayText };
    private readonly DataGridView _gridReports = Ui.Grid("gridReports");
    private readonly DataGridView _gridRoomStats = Ui.Grid("gridRoomStats");
    private readonly TextBox _txtAnalyticsSummary = Ui.OutputBox("txtAnalyticsSummary");

    private TabPage BuildAnalyticsTab()
    {
        _cmbFilterType.Items.AddRange(new object[] { "Все типы", "Sensor — датчики", "Actuator — актуаторы" });
        _cmbFilterType.SelectedIndex = 0;

        EventHandler refresh = (_, _) =>
        {
            if (!_updatingSelectors) RefreshAnalytics();
        };
        _numMinPower.ValueChanged += refresh;
        _cmbFilterType.SelectedIndexChanged += refresh;
        _cmbFilterFloor.SelectedIndexChanged += refresh;
        _txtSearch.TextChanged += refresh;
        _chkOnlyCritical.CheckedChanged += refresh;
        _btnDeferred.Click += (_, _) =>
            WriteOutput(_txtAnalyticsSummary, "Отложенное выполнение", CreateAnalytics().DemonstrateDeferredExecution());

        FlowLayoutPanel filters = Ui.Toolbar(
            Ui.Label("Мощность от, Вт"), _numMinPower,
            Ui.Label("Тип"), _cmbFilterType,
            Ui.Label("Этаж"), _cmbFilterFloor,
            Ui.Label("Поиск (модель / комната)"), _txtSearch,
            _chkOnlyCritical, _btnDeferred, _lblFilterCount);

        TableLayoutPanel bottom = Ui.Columns(
            (Ui.Group("GroupBy(d => d.RoomTitle): Count / Sum / Average / Max / Aggregate", _gridRoomStats), SizeType.Percent, 58),
            (Ui.Group("Сводка: агрегаты, GroupJoin, отложенное выполнение", _txtAnalyticsSummary), SizeType.Percent, 42));

        TableLayoutPanel root = Ui.Rows(
            (filters, SizeType.AutoSize, 0),
            (Ui.Group("DeviceReportDto: Join(Devices, Rooms) + GroupJoin(TelemetryLogs) → Where → OrderBy(Floor) → ThenByDescending(Power)", _gridReports), SizeType.Percent, 55),
            (bottom, SizeType.Percent, 45));

        TabPage page = Ui.Page("LINQ-Аналитика && DTO", "tabAnalytics");
        page.Controls.Add(root);
        return page;
    }

    private DeviceFilter ReadFilter() => new()
    {
        MinPower = (double)_numMinPower.Value,
        Type = _cmbFilterType.SelectedIndex switch
        {
            1 => SmartSensor.TypeName,
            2 => SmartActuator.TypeName,
            _ => null,
        },
        Floor = (_cmbFilterFloor.SelectedItem as FloorItem)?.Floor,
        SearchText = _txtSearch.Text,
        OnlyCritical = _chkOnlyCritical.Checked,
    };

    private void RefreshAnalytics()
    {
        LinqAnalyticsService analytics = CreateAnalytics();
        List<DeviceReportDto> reports = analytics.BuildDeviceReports();

        IEnumerable<DeviceReportDto> query = LinqAnalyticsService.FilterAndSort(reports, ReadFilter());
        List<DeviceReportDto> filtered = query.ToList();

        _gridReports.DataSource = filtered;
        _gridRoomStats.DataSource = LinqAnalyticsService.BuildRoomStatistics(filtered);
        _lblFilterCount.Text = $"Найдено: {filtered.Count} из {reports.Count}";
        WriteOutput(_txtAnalyticsSummary, "Сводка по текущей выборке", BuildAnalyticsSummary(analytics, reports, filtered));
    }

    private static string BuildAnalyticsSummary(LinqAnalyticsService analytics, List<DeviceReportDto> all, List<DeviceReportDto> filtered)
    {
        var text = new StringBuilder();
        text.AppendLine($"Join + GroupJoin -> DeviceReportDto: {all.Count};  после Where: {filtered.Count}");

        if (filtered.Count > 0)
        {
            text.AppendLine($"Sum(Power)                     = {filtered.Sum(d => d.Power):F1} Вт");
            text.AppendLine($"Aggregate(0.0, (s, d) => s + p) = {LinqAnalyticsService.TotalPower(filtered):F1} Вт");
            text.AppendLine($"Average / Min / Max (Power)    = {filtered.Average(d => d.Power):F1} / {filtered.Min(d => d.Power):F1} / {filtered.Max(d => d.Power):F1} Вт");
            text.AppendLine($"Sum(ReadingsCount)             = {filtered.Sum(d => d.ReadingsCount)} показаний");
            text.AppendLine($"Count(IsCritical)              = {filtered.Count(d => d.IsCritical)}");
        }

        text.AppendLine();
        text.AppendLine("GroupBy(d => d.Floor):");
        foreach (IGrouping<int, DeviceReportDto> floor in filtered.GroupBy(d => d.Floor).OrderBy(g => g.Key))
        {
            text.AppendLine($"  этаж {floor.Key}: {floor.Count()} приборов, {floor.Sum(d => d.Power):F1} Вт, " +
                            $"комнат: {floor.Select(d => d.RoomTitle).Distinct().Count()}");
        }

        string empty = string.Join(", ", analytics.CountDevicesPerRoom().Where(x => x.DeviceCount == 0).Select(x => x.Room.Title));
        text.AppendLine();
        text.AppendLine($"GroupJoin(Rooms, Devices) — левое соединение; пустые комнаты: {(empty.Length == 0 ? "нет" : empty)}");
        text.AppendLine("(GroupBy по приборам пустые комнаты не видит — в нём нет ни одного элемента для такой группы.)");
        text.AppendLine();
        text.AppendLine("Кнопка «Отложенное выполнение» покажет разницу IEnumerable / ToList().");
        return text.ToString();
    }
}
