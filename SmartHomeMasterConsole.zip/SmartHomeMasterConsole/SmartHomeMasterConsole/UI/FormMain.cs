using System.ComponentModel;
using System.Diagnostics;
using SmartHomeMasterConsole.Data;
using SmartHomeMasterConsole.Models;
using SmartHomeMasterConsole.Services;

namespace SmartHomeMasterConsole.UI;

[DesignerCategory("Code")]
public partial class FormMain : Form
{
    private const int MaxLogItems = 2000;

    private readonly SmartHomeDataStore _store;
    private readonly TelemetryPollingService _polling;

    private readonly Action<string> _log;

    private readonly TabControl _tabs = new() { Name = "tabsMain", Dock = DockStyle.Fill, Padding = new Point(14, 5) };
    private readonly StatusStrip _statusStrip = new() { Name = "statusStrip" };
    private readonly ToolStripStatusLabel _statusLabel = new() { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly ToolStripProgressBar _statusProgress = new() { Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 30, Visible = false };

    private bool _updatingSelectors;

    public FormMain(string databasePath)
    {
        _store = new SmartHomeDataStore(databasePath);
        _polling = new TelemetryPollingService(_store.Telemetry, _store.Rooms);
        _log = message => Log(message);

        SuspendLayout();
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        Name = "FormMain";
        Text = "SmartHome Master Console";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1100, 720);
        Size = new Size(1320, 840);

        _tabs.TabPages.Add(BuildRegistryTab());
        _tabs.TabPages.Add(BuildPollingTab());
        _tabs.TabPages.Add(BuildAnalyticsTab());
        _tabs.TabPages.Add(BuildSetsAndPagingTab());

        _statusStrip.Items.Add(_statusLabel);
        _statusStrip.Items.Add(_statusProgress);

        Controls.Add(_tabs);
        Controls.Add(_statusStrip);
        ResumeLayout(false);
        PerformLayout();
    }

    protected override async void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        await ReloadAllAsync();
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        _pollCts?.Cancel();
        UnsubscribeFromDevices();
        base.OnFormClosing(e);
    }

    private async Task ReloadAllAsync()
    {
        SetBusy(true, "Загрузка данных из SQLite (async)...");
        try
        {
            UnsubscribeFromDevices();
            var stopwatch = Stopwatch.StartNew();
            await _store.LoadAsync();
            stopwatch.Stop();

            _polling.ClearCache();
            ApplyEventSubscription();
            RefreshAllViews();

            Log($"Данные загружены асинхронно за {stopwatch.ElapsedMilliseconds} мс: комнат {_store.RoomList.Count}, " +
                $"приборов {_store.DeviceList.Count}, записей телеметрии {_store.LogList.Count}" +
                (_store.WasSeeded ? " (база создана и заполнена демо-данными)" : string.Empty), LogKind.Success);
        }
        catch (Exception ex)
        {
            ShowError("Не удалось загрузить данные из SQLite", ex);
        }
        finally
        {
            SetBusy(false);
        }
    }

    private void RefreshAllViews()
    {
        RefreshRoomSelectors();
        RefreshRegistryGrid();
        RefreshAnalytics();
        CompareSelectedRooms();
        RefreshPage();
        UpdateStatusBar();
    }

    private LinqAnalyticsService CreateAnalytics() => new(_store.RoomList, _store.DeviceList, _store.LogList);

    private void RefreshRoomSelectors()
    {
        _updatingSelectors = true;
        try
        {
            Room[] rooms = _store.RoomList.OrderBy(r => r.Floor).ThenBy(r => r.Title).ToArray();
            ResetItems(_cmbNewRoom, rooms, item => ((Room)item).Title == "Гостиная");
            ResetItems(_cmbRoomA, rooms, item => ((Room)item).Title == "Гостиная");
            ResetItems(_cmbRoomB, rooms, item => ((Room)item).Title == "Детская");

            IEnumerable<FloorItem> floors = rooms
                .Select(r => r.Floor)
                .Distinct()
                .OrderBy(floor => floor)
                .Select(floor => new FloorItem(floor))
                .Prepend(new FloorItem(null));
            ResetItems(_cmbFilterFloor, floors);
        }
        finally
        {
            _updatingSelectors = false;
        }
    }

    private static void ResetItems(ComboBox combo, IEnumerable<object> items, Func<object, bool>? preferred = null)
    {
        string previous = combo.SelectedItem?.ToString() ?? string.Empty;
        combo.BeginUpdate();
        combo.Items.Clear();
        foreach (object item in items) combo.Items.Add(item);
        combo.EndUpdate();
        if (combo.Items.Count == 0) return;

        List<object> all = combo.Items.Cast<object>().ToList();
        int index = all.FindIndex(item => item.ToString() == previous);
        if (index < 0 && preferred is not null) index = all.FindIndex(item => preferred(item));
        combo.SelectedIndex = Math.Max(index, 0);
    }

    private void UpdateStatusBar() =>
        _statusLabel.Text = $"БД: {_store.DatabasePath}   |   комнат: {_store.RoomList.Count}   " +
                            $"приборов: {_store.DeviceList.Count}   записей телеметрии: {_store.LogList.Count}";

    private void SetBusy(bool busy, string? message = null)
    {
        _statusProgress.Visible = busy;
        UseWaitCursor = busy;
        if (busy && message is not null) _statusLabel.Text = message;
        if (!busy) UpdateStatusBar();
    }

    private void Log(string text, LogKind kind = LogKind.Info, DateTime? time = null)
    {
        if (IsDisposed) return;
        if (InvokeRequired)
        {
            if (IsHandleCreated) BeginInvoke(new Action(() => Log(text, kind, time)));
            return;
        }

        _lstLog.Items.Add(new LogEntry(time ?? DateTime.Now, text, kind));
        while (_lstLog.Items.Count > MaxLogItems) _lstLog.Items.RemoveAt(0);
        _lstLog.TopIndex = Math.Max(0, _lstLog.Items.Count - 1);
    }

    private static void WriteOutput(TextBox box, string title, string body) =>
        box.Text = Ui.ToWindowsNewLines($"=== {title} ===\n{body.TrimEnd()}");

    private void Warn(string message) =>
        MessageBox.Show(this, message, "SmartHome Master Console", MessageBoxButtons.OK, MessageBoxIcon.Information);

    private void ShowError(string title, Exception ex)
    {
        Log($"{title}: {ex.Message}", LogKind.Critical);
        MessageBox.Show(this, ex.Message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    private sealed record FloorItem(int? Floor)
    {
        public override string ToString() => Floor is null ? "Все этажи" : $"Этаж {Floor}";
    }
}
