using System.ComponentModel;
using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.UI;

internal sealed class DeviceGridRow
{
    public DeviceGridRow(Device device, string roomTitle)
    {
        Source = device;
        Room = roomTitle;
    }

    [Browsable(false)]
    public Device Source { get; }

    [DisplayName("Id")]
    public int Id => Source.Id;

    [DisplayName("Комната")]
    public string Room { get; }

    [DisplayName("Тип")]
    public string Type => Source.TypeDisplayName;

    [DisplayName("Модель")]
    public string Model => Source.Model;

    [DisplayName("Мощность, Вт")]
    public double Power => Source.Power;

    [DisplayName("Точность / нагрузка")]
    public string Extra => Source switch
    {
        SmartSensor sensor => $"±{sensor.Accuracy:0.##} %",
        SmartActuator actuator => $"до {actuator.LoadCapacity:0} Вт",
        _ => string.Empty,
    };

    [DisplayName("Потребление, Вт")]
    public double Consumption => Math.Round(Source.CalculatePowerConsumption(), 2);

    [DisplayName("Последнее показание")]
    public string LastReading => Source.LastReading is double value
        ? $"{value:0.##} {Source.Passport.Unit}".TrimEnd()
        : "—";

    [DisplayName("Вкл.")]
    public bool Active => Source.IsActive;

    [DisplayName("Серийный №")]
    public string Serial => Source.Passport.SerialNumber;
}
