using System.Text;
using SmartHomeMasterConsole.Dto;
using SmartHomeMasterConsole.Models;
using SmartHomeMasterConsole.Services;

namespace SmartHomeMasterConsole.UI;

public partial class FormMain
{
    private const double HighPowerLimit = 5000;
    private const double HeavyPowerLimit = 1000;

    private readonly ComboBox _cmbRoomA = Ui.DropDown("cmbRoomA", 190);
    private readonly ComboBox _cmbRoomB = Ui.DropDown("cmbRoomB", 190);
    private readonly ListBox _lstCommon = Ui.List("lstCommon");
    private readonly ListBox _lstOnlyA = Ui.List("lstOnlyA");
    private readonly ListBox _lstOnlyB = Ui.List("lstOnlyB");
    private readonly ListBox _lstUnion = Ui.List("lstUnion");
    private readonly GroupBox _grpCommon = new() { Text = "Общие — Intersect" };
    private readonly GroupBox _grpOnlyA = new() { Text = "Только в A — Except" };
    private readonly GroupBox _grpOnlyB = new() { Text = "Только в B — Except" };
    private readonly GroupBox _grpUnion = new() { Text = "Все модели — Union" };
    private readonly TextBox _txtSetsInfo = Ui.OutputBox("txtSetsInfo");

    private readonly NumericUpDown _numPageSize = Ui.Number("numPageSize", 1, 50, 0, 8, 70);
    private readonly Button _btnFirstPage = Ui.Button("|<  Первая", "btnFirstPage");
    private readonly Button _btnPrevPage = Ui.Button("<  Назад", "btnPrevPage");
    private readonly Button _btnNextPage = Ui.Button("Вперёд  >", "btnNextPage");
    private readonly Button _btnLastPage = Ui.Button("Последняя  >|", "btnLastPage");
    private readonly Label _lblPageInfo = new() { Name = "lblPageInfo", AutoSize = true, Margin = new Padding(12, 8, 3, 3) };
    private readonly DataGridView _gridPage = Ui.Grid("gridPage");

    private int _currentPage = 1;

    private TabPage BuildSetsAndPagingTab()
    {
        Button btnCompare = Ui.Button("Сравнить комнаты", "btnCompareRooms");
        btnCompare.Click += (_, _) => CompareSelectedRooms();
        _cmbRoomA.SelectedIndexChanged += (_, _) => { if (!_updatingSelectors) CompareSelectedRooms(); };
        _cmbRoomB.SelectedIndexChanged += (_, _) => { if (!_updatingSelectors) CompareSelectedRooms(); };

        _grpCommon.Controls.Add(_lstCommon);
        _grpOnlyA.Controls.Add(_lstOnlyA);
        _grpOnlyB.Controls.Add(_lstOnlyB);
        _grpUnion.Controls.Add(_lstUnion);

        FlowLayoutPanel selectors = Ui.Toolbar(
            Ui.Label("Комната A"), _cmbRoomA,
            Ui.Label("Комната B"), _cmbRoomB,
            btnCompare,
            Ui.Label("сравнение по модели: DeviceModelComparer : IEqualityComparer<Device>"));

        TableLayoutPanel lists = Ui.Columns(
            (_grpCommon, SizeType.Percent, 15),
            (_grpOnlyA, SizeType.Percent, 15),
            (_grpOnlyB, SizeType.Percent, 15),
            (_grpUnion, SizeType.Percent, 15),
            (Ui.Group("Equals-множества и квантификаторы Any / All / FirstOrDefault", _txtSetsInfo), SizeType.Percent, 40));

        GroupBox sets = Ui.Group("Множества: Intersect / Except / Union",
            Ui.Rows((selectors, SizeType.AutoSize, 0), (lists, SizeType.Percent, 100)));

        _numPageSize.ValueChanged += (_, _) => { _currentPage = 1; RefreshPage(); };
        _btnFirstPage.Click += (_, _) => { _currentPage = 1; RefreshPage(); };
        _btnPrevPage.Click += (_, _) => { _currentPage--; RefreshPage(); };
        _btnNextPage.Click += (_, _) => { _currentPage++; RefreshPage(); };
        _btnLastPage.Click += (_, _) => { _currentPage = int.MaxValue; RefreshPage(); };

        FlowLayoutPanel navigation = Ui.Toolbar(
            Ui.Label("Размер страницы"), _numPageSize,
            _btnFirstPage, _btnPrevPage, _btnNextPage, _btnLastPage, _lblPageInfo);

        GroupBox paging = Ui.Group("Пагинация: OrderBy(Floor).ThenByDescending(Power).Skip((page - 1) * pageSize).Take(pageSize)",
            Ui.Rows((navigation, SizeType.AutoSize, 0), (_gridPage, SizeType.Percent, 100)));

        TableLayoutPanel root = Ui.Rows((sets, SizeType.Percent, 48), (paging, SizeType.Percent, 52));

        TabPage page = Ui.Page("Множества && Пагинация", "tabSetsPaging");
        page.Controls.Add(root);
        return page;
    }

    private void CompareSelectedRooms()
    {
        if (_cmbRoomA.SelectedItem is not Room roomA || _cmbRoomB.SelectedItem is not Room roomB) return;

        LinqAnalyticsService analytics = CreateAnalytics();
        RoomComparisonResult result = analytics.CompareRooms(roomA.Id, roomB.Id);

        FillDeviceList(_lstCommon, _grpCommon, "Общие — Intersect", result.Common);
        FillDeviceList(_lstOnlyA, _grpOnlyA, "Только в A — Except", result.OnlyInA);
        FillDeviceList(_lstOnlyB, _grpOnlyB, "Только в B — Except", result.OnlyInB);
        FillDeviceList(_lstUnion, _grpUnion, "Все модели — Union", result.Union);

        var text = new StringBuilder()
            .AppendLine($"A = {result.RoomA.Title}: {result.CountA} приб.;  B = {result.RoomB.Title}: {result.CountB} приб.")
            .AppendLine($"A.Intersect(B) = {result.Common.Count};  A.Except(B) = {result.OnlyInA.Count};  " +
                        $"B.Except(A) = {result.OnlyInB.Count};  A.Union(B) = {result.Union.Count}")
            .AppendLine()
            .AppendLine("Множества объектов Device без компаратора — по переопределённому Equals (Id + Model):");
        foreach (string line in analytics.DescribeEqualityBasedSets(HeavyPowerLimit)) text.AppendLine("  " + line);
        text.AppendLine().AppendLine("Квантификаторы и безопасная выборка:");
        foreach (string line in analytics.RunQuantifierChecks(HighPowerLimit).ToLines()) text.AppendLine("  " + line);

        WriteOutput(_txtSetsInfo, "Проверки", text.ToString());
    }

    private static void FillDeviceList(ListBox list, GroupBox group, string title, IReadOnlyList<Device> devices)
    {
        list.BeginUpdate();
        list.Items.Clear();
        foreach (Device device in devices.OrderBy(d => d.Model))
            list.Items.Add($"{device.Model} ({device.TypeDisplayName.ToLowerInvariant()})");
        list.EndUpdate();
        group.Text = $"{title} ({devices.Count})";
    }

    private void RefreshPage()
    {
        List<DeviceReportDto> reports = CreateAnalytics().BuildDeviceReports();
        IEnumerable<DeviceReportDto> ordered = LinqAnalyticsService.FilterAndSort(reports, DeviceFilter.All);
        PagedResult<DeviceReportDto> page = LinqAnalyticsService.Paginate(ordered, _currentPage, (int)_numPageSize.Value);

        _currentPage = page.PageNumber;
        _gridPage.DataSource = page.Items;
        _lblPageInfo.Text = $"Страница {page.PageNumber} из {page.TotalPages}  |  записи {page.FirstItemNumber}–{page.LastItemNumber} " +
                            $"из {page.TotalCount}  |  Skip({page.Skipped}).Take({page.PageSize})";
        _btnFirstPage.Enabled = _btnPrevPage.Enabled = page.HasPrevious;
        _btnNextPage.Enabled = _btnLastPage.Enabled = page.HasNext;
    }
}
