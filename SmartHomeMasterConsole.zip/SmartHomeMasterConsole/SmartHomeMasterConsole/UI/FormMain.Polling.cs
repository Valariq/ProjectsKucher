using System.Diagnostics;
using SmartHomeMasterConsole.Dto;
using SmartHomeMasterConsole.Events;
using SmartHomeMasterConsole.Models;
using SmartHomeMasterConsole.Services;

namespace SmartHomeMasterConsole.UI;

public partial class FormMain
{
    private readonly Button _btnPoll = Ui.Button("Опросить активные приборы — Task.WhenAll", "btnPoll");
    private readonly Button _btnCancelPoll = Ui.Button("Отменить опрос — CancellationToken", "btnCancelPoll");
    private readonly ProgressBar _progressPoll = new() { Name = "progressPoll", Height = 18, Margin = new Padding(3, 6, 3, 3) };
    private readonly Label _lblPollSummary = new() { Name = "lblPollSummary", AutoSize = true, Text = "Опрос ещё не запускался.", ForeColor = SystemColors.GrayText, MaximumSize = new Size(330, 0), Margin = new Padding(3, 6, 3, 3) };
    private readonly CheckBox _chkSubscribe = new() { Name = "chkSubscribe", Text = "Подписаться на StatusChanged всех приборов", Checked = true, AutoSize = true };
    private readonly Button _btnClearLog = Ui.Button("Очистить журнал", "btnClearLog");
    private readonly Button _btnValueTask = Ui.Button("Названия комнат — ValueTask<string> + кэш", "btnValueTask");
    private readonly Button _btnClearCache = Ui.Button("Сбросить кэш", "btnClearCache");
    private readonly Button _btnPredicate = Ui.Button("Критические — Predicate<Device>", "btnPredicate");
    private readonly Button _btnFunc = Ui.Button("Потребление — Func<Device, double>", "btnFunc");
    private readonly NumericUpDown _numThreshold = Ui.Number("numThreshold", 0, 100000, 0, 1000);
    private readonly Button _btnCreateChecker = Ui.Button("Создать проверку порога — замыкание", "btnCreateChecker");
    private readonly Button _btnApplyChecker = Ui.Button("Применить созданную проверку", "btnApplyChecker");
    private readonly ListBox _lstLog = new() { Name = "lstLog", Dock = DockStyle.Fill, DrawMode = DrawMode.OwnerDrawFixed, IntegralHeight = false };

    private CancellationTokenSource? _pollCts;
    private Func<double, bool>? _thresholdChecker;
    private double _checkerThreshold;

    private TabPage BuildPollingTab()
    {
        _btnPoll.Click += BtnPoll_Click;
        _btnCancelPoll.Enabled = false;
        _btnCancelPoll.Click += (_, _) => _pollCts?.Cancel();
        _chkSubscribe.CheckedChanged += (_, _) =>
        {
            ApplyEventSubscription();
            Log(_chkSubscribe.Checked
                ? "Подписка на StatusChanged включена (+=) для всех приборов."
                : "Подписка на StatusChanged снята (-=): события больше не попадают в журнал.");
        };
        _btnClearLog.Click += (_, _) => _lstLog.Items.Clear();
        _btnValueTask.Click += BtnValueTask_Click;
        _btnClearCache.Click += (_, _) =>
        {
            _polling.ClearCache();
            Log("Кэш названий комнат очищен — следующий вызов снова обратится к SQLite.");
        };
        _btnPredicate.Click += BtnPredicate_Click;
        _btnFunc.Click += BtnFunc_Click;
        _btnCreateChecker.Click += BtnCreateChecker_Click;
        _btnApplyChecker.Click += BtnApplyChecker_Click;
        _btnApplyChecker.Enabled = false;

        _lstLog.ItemHeight = _lstLog.Font.Height + 6;
        _lstLog.DrawItem += LstLog_DrawItem;
        _lstLog.DoubleClick += (_, _) =>
        {
            if (_lstLog.SelectedItem is LogEntry entry)
                MessageBox.Show(this, entry.ToString(), "Запись журнала", MessageBoxButtons.OK, MessageBoxIcon.Information);
        };

        FlowLayoutPanel side = Ui.SidePanel(
            Ui.Section("Асинхронный опрос — async / await"),
            _btnPoll, _btnCancelPoll, _progressPoll, _lblPollSummary,
            Ui.Section("Событие StatusChanged"),
            _chkSubscribe, _btnClearLog,
            Ui.Section("Кэшированные вызовы — ValueTask<string>"),
            _btnValueTask, _btnClearCache,
            Ui.Section("Делегаты и замыкание"),
            _btnPredicate, _btnFunc,
            Ui.Inline(Ui.Label("Порог, Вт"), _numThreshold),
            _btnCreateChecker, _btnApplyChecker);

        TableLayoutPanel root = Ui.Columns(
            (side, SizeType.Absolute, Ui.SidePanelWidth),
            (Ui.Group("Журнал событий и сообщений — ListBox (двойной щелчок — полный текст)", _lstLog), SizeType.Percent, 100));

        TabPage page = Ui.Page("Асинхронный опрос && Events", "tabPolling");
        page.Controls.Add(root);
        return page;
    }

    private void ApplyEventSubscription()
    {
        foreach (Device device in _store.DeviceList)
        {
            device.StatusChanged -= Device_StatusChanged;
            if (_chkSubscribe.Checked)
                device.StatusChanged += Device_StatusChanged;
        }
    }

    private void UnsubscribeFromDevices()
    {
        foreach (Device device in _store.DeviceList)
            device.StatusChanged -= Device_StatusChanged;
    }

    private void Device_StatusChanged(object? sender, DeviceEventArgs e)
    {
        if (IsDisposed) return;
        if (InvokeRequired)
        {
            if (IsHandleCreated) BeginInvoke(new Action(() => Device_StatusChanged(sender, e)));
            return;
        }

        string prefix = sender is Device device ? device.TypeDisplayName + " " : string.Empty;
        Log(prefix + e.Message, e.IsCritical ? LogKind.Critical : LogKind.Event, e.Timestamp);
    }

    private void LstLog_DrawItem(object? sender, DrawItemEventArgs e)
    {
        if (e.Index < 0 || e.Index >= _lstLog.Items.Count) return;

        e.DrawBackground();
        bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
        var entry = (LogEntry)_lstLog.Items[e.Index];
        Color color = selected ? SystemColors.HighlightText : entry.Kind switch
        {
            LogKind.Critical => Color.Firebrick,
            LogKind.Event => Color.FromArgb(0, 84, 147),
            LogKind.Success => Color.ForestGreen,
            _ => SystemColors.WindowText,
        };
        TextRenderer.DrawText(e.Graphics, entry.ToString(), _lstLog.Font, e.Bounds, color,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
            TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        e.DrawFocusRectangle();
    }

    private async void BtnPoll_Click(object? sender, EventArgs e)
    {
        List<Device> targets = _store.DeviceList.Where(d => d.IsActive).ToList();
        if (targets.Count == 0)
        {
            Log("Нет активных приборов для опроса.", LogKind.Critical);
            return;
        }

        _pollCts = new CancellationTokenSource();
        _btnPoll.Enabled = false;
        _btnCancelPoll.Enabled = true;
        _progressPoll.Maximum = targets.Count;
        _progressPoll.Value = 0;
        _lblPollSummary.Text = "Идёт опрос...";

        var progress = new Progress<int>(done => _progressPoll.Value = Math.Min(done, _progressPoll.Maximum));
        Log($"Старт параллельного опроса {targets.Count} активных приборов. Окно остаётся отзывчивым — можно переключать вкладки.");

        var stopwatch = Stopwatch.StartNew();
        try
        {
            PollResult[] results = await _polling.PollAllAsync(targets, progress, _pollCts.Token);
            stopwatch.Stop();

            double sequentialMs = results.Sum(r => r.Latency.TotalMilliseconds);
            int critical = results.Count(r => r.IsCritical);
            string summary =
                $"Опрошено {results.Length} приборов за {stopwatch.ElapsedMilliseconds} мс. " +
                $"Последовательно это заняло бы ~{sequentialMs:F0} мс (в {sequentialMs / Math.Max(1, stopwatch.ElapsedMilliseconds):F1} раза дольше). " +
                $"Критичных: {critical}. Показания записаны в TelemetryLogs.";
            _lblPollSummary.Text = summary;
            Log(summary, LogKind.Success);

            await _store.ReloadTelemetryAsync();
            RefreshRegistryGrid();
            RefreshAnalytics();
            CompareSelectedRooms();
            RefreshPage();
            UpdateStatusBar();
        }
        catch (OperationCanceledException)
        {
            _lblPollSummary.Text = "Опрос отменён.";
            Log("Опрос отменён через CancellationToken — полученные показания в базу не записаны.", LogKind.Critical);
        }
        catch (Exception ex)
        {
            ShowError("Ошибка опроса", ex);
        }
        finally
        {
            _pollCts.Dispose();
            _pollCts = null;
            _btnPoll.Enabled = true;
            _btnCancelPoll.Enabled = false;
        }
    }

    private async void BtnValueTask_Click(object? sender, EventArgs e)
    {
        _btnValueTask.Enabled = false;
        try
        {
            var stopwatch = Stopwatch.StartNew();
            int fromCache = 0, fromDatabase = 0;
            var reported = new HashSet<int>();
            Log("ValueTask<string>: запрашиваем название комнаты для каждого прибора...");

            foreach (Device device in _store.DeviceList.OrderBy(d => d.RoomId).ThenBy(d => d.Id))
            {
                ValueTask<string> pending = _polling.GetRoomTitleAsync(device.RoomId);
                bool synchronous = pending.IsCompletedSuccessfully;
                string title = await pending;

                if (synchronous) fromCache++;
                else fromDatabase++;

                if (reported.Add(device.RoomId))
                    Log($"  комната #{device.RoomId} «{title}» — {(synchronous ? "из кэша, синхронно" : "из SQLite, асинхронно")}");
            }

            stopwatch.Stop();
            Log($"ValueTask<string>: {fromCache + fromDatabase} вызовов за {stopwatch.ElapsedMilliseconds} мс — " +
                $"из SQLite: {fromDatabase}, из кэша: {fromCache}. Повторный запуск — все ответы из кэша.", LogKind.Success);
        }
        catch (Exception ex)
        {
            ShowError("Ошибка ValueTask-запроса", ex);
        }
        finally
        {
            _btnValueTask.Enabled = true;
        }
    }

    private void BtnPredicate_Click(object? sender, EventArgs e)
    {
        Predicate<Device> isCritical = DeviceDelegates.IsCritical;
        List<Device> critical = _store.DeviceList.FindAll(isCritical);

        Log($"Predicate<Device> -> List.FindAll: критичных {critical.Count} из {_store.DeviceList.Count}; " +
            $"Exists = {_store.DeviceList.Exists(isCritical)}, FindIndex = {_store.DeviceList.FindIndex(isCritical)}",
            critical.Count > 0 ? LogKind.Critical : LogKind.Success);

        Action<Device> report = device => Log("  " + device.GetStatus(), LogKind.Critical);
        critical.ForEach(report);
    }

    private void BtnFunc_Click(object? sender, EventArgs e)
    {
        Func<Device, double> consumption = DeviceDelegates.CurrentConsumption;
        Func<Device, double> daily = DeviceDelegates.DailyEnergyKWh;

        Log($"Func<Device, double>: суммарное текущее потребление {_store.DeviceList.Sum(consumption):F1} Вт, " +
            $"за сутки ~{_store.DeviceList.Sum(daily):F1} кВт·ч. Топ-5 потребителей:");
        foreach (Device device in _store.DeviceList.OrderByDescending(consumption).Take(5))
            Log($"  {device.Title}: {consumption(device):F1} Вт ({daily(device):F2} кВт·ч/сут)");
    }

    private void BtnCreateChecker_Click(object? sender, EventArgs e)
    {
        double threshold = (double)_numThreshold.Value;
        _thresholdChecker = DeviceDelegates.CreatePowerThresholdChecker(threshold, _log);
        _checkerThreshold = threshold;
        _btnApplyChecker.Enabled = true;

        Log($"Создана функция Func<double, bool> с порогом {threshold:F0} Вт — значение захвачено замыканием. " +
            "Измените число в поле: уже созданная функция продолжит использовать старый порог.");
    }

    private void BtnApplyChecker_Click(object? sender, EventArgs e)
    {
        if (_thresholdChecker is null) return;

        Log($"Проверка замыканием: захваченный порог {_checkerThreshold:F0} Вт, в поле сейчас {_numThreshold.Value:F0} Вт.");
        List<string> exceeded = _store.DeviceList
            .Where(device => _thresholdChecker(DeviceDelegates.CurrentConsumption(device)))
            .Select(device => device.Model)
            .ToList();
        Log($"  итого превышают порог: {exceeded.Count} — {string.Join(", ", exceeded)}. " +
            "Номера превышений растут от запуска к запуску: счётчик живёт внутри замыкания.", LogKind.Success);
    }
}
