namespace SmartHomeMasterConsole.UI;

internal static class Ui
{
    public const int SidePanelWidth = 370;
    private const int SideContentWidth = SidePanelWidth - 32;

    public static Font MonospaceFont { get; } = new("Consolas", 9.5f);

    public static Font SectionFont { get; } = new(Control.DefaultFont, FontStyle.Bold);

    public static TabPage Page(string text, string name) => new(text)
    {
        Name = name,
        Padding = new Padding(6),
        UseVisualStyleBackColor = true,
    };

    public static Button Button(string text, string name) => new()
    {
        Text = text,
        Name = name,
        AutoSize = true,
        MinimumSize = new Size(0, 30),
        Padding = new Padding(6, 2, 6, 2),
        Margin = new Padding(3),
        UseVisualStyleBackColor = true,
    };

    public static Label Label(string text) => new()
    {
        Text = text,
        AutoSize = true,
        Margin = new Padding(3, 7, 3, 3),
    };

    public static Label Section(string text) => new()
    {
        Text = text,
        AutoSize = true,
        Font = SectionFont,
        Margin = new Padding(3, 12, 3, 4),
    };

    public static ComboBox DropDown(string name, int width = 160) => new()
    {
        Name = name,
        Width = width,
        DropDownStyle = ComboBoxStyle.DropDownList,
    };

    public static NumericUpDown Number(string name, decimal minimum, decimal maximum, int decimals, decimal value, int width = 100) => new()
    {
        Name = name,
        Minimum = minimum,
        Maximum = maximum,
        DecimalPlaces = decimals,
        Increment = decimals > 0 ? 0.1m : 1m,
        Value = value,
        Width = width,
    };

    public static TextBox OutputBox(string name) => new()
    {
        Name = name,
        AutoSize = false,
        Multiline = true,
        ReadOnly = true,
        WordWrap = true,
        ScrollBars = ScrollBars.Vertical,
        Font = MonospaceFont,
        BackColor = SystemColors.Window,
        Dock = DockStyle.Fill,
    };

    public static ListBox List(string name) => new()
    {
        Name = name,
        Dock = DockStyle.Fill,
        IntegralHeight = false,
    };

    public static DataGridView Grid(string name)
    {
        var grid = new DataGridView
        {
            Name = name,
            Dock = DockStyle.Fill,
            ReadOnly = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            AllowUserToResizeRows = false,
            AutoGenerateColumns = true,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false,
            RowHeadersVisible = false,
            BackgroundColor = SystemColors.Window,
            BorderStyle = BorderStyle.FixedSingle,
        };
        grid.DataBindingComplete += (_, _) => FormatColumns(grid);
        return grid;
    }

    public static GroupBox Group(string title, Control content)
    {
        var box = new GroupBox { Text = title, Dock = DockStyle.Fill, Padding = new Padding(8, 6, 8, 8) };
        content.Dock = DockStyle.Fill;
        box.Controls.Add(content);
        return box;
    }

    public static FlowLayoutPanel SidePanel(params Control[] items)
    {
        var panel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            Padding = new Padding(4, 0, 4, 4),
        };

        foreach (Control item in items)
        {
            switch (item)
            {
                case Button button:
                    button.AutoSize = false;
                    button.Size = new Size(SideContentWidth, 32);
                    break;
                case ProgressBar progress:
                    progress.Width = SideContentWidth;
                    break;
                case Label label when label.Font != SectionFont:
                    label.MaximumSize = new Size(SideContentWidth, 0);
                    break;
            }
            panel.Controls.Add(item);
        }
        return panel;
    }

    public static FlowLayoutPanel Inline(params Control[] controls)
    {
        var panel = new FlowLayoutPanel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0),
        };
        panel.Controls.AddRange(controls);
        return panel;
    }

    public static FlowLayoutPanel Toolbar(params Control[] controls)
    {
        var panel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = true,
            Padding = new Padding(0, 0, 0, 4),
        };
        panel.Controls.AddRange(controls);
        return panel;
    }

    public static TableLayoutPanel FormGrid(int pairsPerRow, params (Control Label, Control Field)[] pairs)
    {
        var grid = new TableLayoutPanel
        {
            ColumnCount = pairsPerRow * 2,
            Dock = DockStyle.Fill,
        };
        for (int i = 0; i < pairsPerRow; i++)
        {
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / pairsPerRow));
        }

        for (int i = 0; i < pairs.Length; i++)
        {
            int row = i / pairsPerRow;
            int column = i % pairsPerRow * 2;
            if (column == 0)
            {
                grid.RowCount = row + 1;
                grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            }

            (Control label, Control field) = pairs[i];
            label.Anchor = AnchorStyles.Left;
            label.Margin = new Padding(column == 0 ? 3 : 14, 7, 3, 3);
            field.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            grid.Controls.Add(label, column, row);
            grid.Controls.Add(field, column + 1, row);
        }
        return grid;
    }

    public static TableLayoutPanel Rows(params (Control Control, SizeType Size, float Value)[] rows)
    {
        var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = rows.Length };
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        for (int i = 0; i < rows.Length; i++)
        {
            panel.RowStyles.Add(new RowStyle(rows[i].Size, rows[i].Value));
            rows[i].Control.Dock = DockStyle.Fill;
            panel.Controls.Add(rows[i].Control, 0, i);
        }
        return panel;
    }

    public static TableLayoutPanel Columns(params (Control Control, SizeType Size, float Value)[] columns)
    {
        var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = columns.Length, RowCount = 1 };
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        for (int i = 0; i < columns.Length; i++)
        {
            panel.ColumnStyles.Add(new ColumnStyle(columns[i].Size, columns[i].Value));
            columns[i].Control.Dock = DockStyle.Fill;
            panel.Controls.Add(columns[i].Control, i, 0);
        }
        return panel;
    }

    public static string ToWindowsNewLines(string text) =>
        text.Replace("\r\n", "\n").Replace("\n", Environment.NewLine);

    private static void FormatColumns(DataGridView grid)
    {
        foreach (DataGridViewColumn column in grid.Columns)
        {
            column.MinimumWidth = 40;
            Type? valueType = column.ValueType is null ? null : Nullable.GetUnderlyingType(column.ValueType) ?? column.ValueType;

            if (valueType == typeof(double))
            {
                column.DefaultCellStyle.Format = "0.##";
                column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            else if (valueType == typeof(int))
            {
                column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                column.FillWeight = 55;
            }
            else if (valueType == typeof(DateTime))
            {
                column.DefaultCellStyle.Format = "dd.MM HH:mm";
            }
            else if (valueType == typeof(bool))
            {
                column.FillWeight = 55;
            }

            if (column.DataPropertyName is "Model" or "Models")
                column.FillWeight = 230;
        }
    }
}
