namespace SmartHomeMasterConsole.UI;

internal enum LogKind
{
    Info,
    Event,
    Critical,
    Success,
}

internal sealed class LogEntry
{
    public LogEntry(DateTime time, string text, LogKind kind)
    {
        Time = time;
        Text = text;
        Kind = kind;
    }

    public DateTime Time { get; }
    public string Text { get; }
    public LogKind Kind { get; }

    public override string ToString() => $"[{Time:HH:mm:ss.fff}] {Text}";
}
