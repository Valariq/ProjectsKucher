using System.ComponentModel;

namespace SmartHomeMasterConsole.Dto;

public sealed class RoomStatisticsDto
{
    [DisplayName("Комната")]
    public string RoomTitle { get; init; } = string.Empty;

    [DisplayName("Этаж")]
    public int Floor { get; init; }

    [DisplayName("Count()")]
    public int DeviceCount { get; init; }

    [DisplayName("Sum(Power), Вт")]
    public double TotalPower { get; init; }

    [DisplayName("Average(Power), Вт")]
    public double AveragePower { get; init; }

    [DisplayName("Max(Power), Вт")]
    public double MaxPower { get; init; }

    [DisplayName("Критичных")]
    public int CriticalCount { get; init; }

    [DisplayName("Модели — Aggregate()")]
    public string Models { get; init; } = string.Empty;
}
