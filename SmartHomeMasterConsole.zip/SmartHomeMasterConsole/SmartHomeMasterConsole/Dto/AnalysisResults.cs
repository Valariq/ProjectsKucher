using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Dto;

public sealed record RoomComparisonResult(
    Room RoomA,
    Room RoomB,
    int CountA,
    int CountB,
    IReadOnlyList<Device> Common,
    IReadOnlyList<Device> OnlyInA,
    IReadOnlyList<Device> OnlyInB,
    IReadOnlyList<Device> Union);

public sealed record QuantifierReport(
    bool AnyCritical,
    bool AllLinkedToRooms,
    bool AllHaveTelemetry,
    double PowerLimit,
    bool AnyOverLimit,
    Device? FirstOverLimit,
    Room? FirstEmptyRoom,
    Device? MissingDevice)
{
    public IEnumerable<string> ToLines()
    {
        yield return $"Any(IsCritical)                      = {AnyCritical}";
        yield return $"All(у прибора есть комната)          = {AllLinkedToRooms}  (ссылочная целостность Devices -> Rooms)";
        yield return $"All(у прибора есть телеметрия)       = {AllHaveTelemetry}";
        yield return $"Any(Power > {PowerLimit:0} Вт)                = {AnyOverLimit}";
        yield return $"FirstOrDefault(Power > {PowerLimit:0} Вт)     = {FirstOverLimit?.Title ?? "null -> «не найдено»"}";
        yield return $"FirstOrDefault(комната без приборов) = {FirstEmptyRoom?.Title ?? "null -> «не найдено»"}";
        yield return $"FirstOrDefault(Id == int.MaxValue)   = {MissingDevice?.Title ?? "null -> обработано через ?. и ??, без NullReferenceException"}";
    }
}

public sealed record DeepCopyReport(bool IsDeepCopy, string Text);

public sealed record PollResult(Device Device, double Reading, DateTime Timestamp, TimeSpan Latency, bool IsCritical);
