namespace SmartHomeMasterConsole.Dto;

public sealed class DeviceFilter
{
    public static DeviceFilter All => new();

    public double MinPower { get; init; }

    public string? Type { get; init; }

    public int? Floor { get; init; }

    public string? SearchText { get; init; }

    public bool OnlyCritical { get; init; }
}
