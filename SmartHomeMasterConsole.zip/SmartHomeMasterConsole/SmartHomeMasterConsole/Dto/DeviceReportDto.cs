using System.ComponentModel;

namespace SmartHomeMasterConsole.Dto;

public sealed class DeviceReportDto
{
    [DisplayName("Id")]
    public int DeviceId { get; init; }

    [DisplayName("Модель")]
    public string Model { get; init; } = string.Empty;

    [DisplayName("Тип")]
    public string Type { get; init; } = string.Empty;

    [DisplayName("Мощность, Вт")]
    public double Power { get; init; }

    [DisplayName("Комната")]
    public string RoomTitle { get; init; } = string.Empty;

    [DisplayName("Этаж")]
    public int Floor { get; init; }

    [DisplayName("Показаний")]
    public int ReadingsCount { get; init; }

    [DisplayName("Среднее показание")]
    public double? AverageReading { get; init; }

    [DisplayName("Последнее показание")]
    public DateTime? LastReadingAt { get; init; }

    [DisplayName("Критично")]
    public bool IsCritical { get; init; }

    public override string ToString() => $"{Model} ({RoomTitle}, этаж {Floor}, {Power:F1} Вт)";
}
