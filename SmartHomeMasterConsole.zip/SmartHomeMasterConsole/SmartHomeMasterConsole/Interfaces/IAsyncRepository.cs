namespace SmartHomeMasterConsole.Interfaces;

public interface IAsyncRepository<T> : IRepository<T> where T : class
{
    Task<T?> FindByIdAsync(int id, CancellationToken cancellationToken = default);

    Task<List<T>> GetAllAsync(CancellationToken cancellationToken = default);

    Task AddAsync(T entity, CancellationToken cancellationToken = default);
}
