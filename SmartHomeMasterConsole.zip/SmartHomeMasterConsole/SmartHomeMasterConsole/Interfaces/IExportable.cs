namespace SmartHomeMasterConsole.Interfaces;

public interface IExportable
{
    string GetExportData();
}
