namespace SmartHomeMasterConsole.Events;

public sealed class DeviceEventArgs : EventArgs
{
    public DeviceEventArgs(string message, bool isCritical = false)
    {
        Message = message;
        IsCritical = isCritical;
        Timestamp = DateTime.Now;
    }

    public string Message { get; }

    public DateTime Timestamp { get; }

    public bool IsCritical { get; }

    public override string ToString() => $"[{Timestamp:HH:mm:ss.fff}] {Message}";
}
