using SmartHomeMasterConsole.UI;

namespace SmartHomeMasterConsole;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();

        Application.ThreadException += (_, e) => ShowFatal(e.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            if (e.ExceptionObject is Exception ex) ShowFatal(ex);
        };

        string databasePath = Path.Combine(AppContext.BaseDirectory, "smart_home.db");
        Application.Run(new FormMain(databasePath));
    }

    private static void ShowFatal(Exception ex) =>
        MessageBox.Show(ex.ToString(), "SmartHome Master Console — ошибка",
            MessageBoxButtons.OK, MessageBoxIcon.Error);
}
