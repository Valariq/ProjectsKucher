PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Rooms (
    Id     INTEGER PRIMARY KEY AUTOINCREMENT,
    Title  TEXT    NOT NULL UNIQUE,
    Floor  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS Devices (
    Id           INTEGER PRIMARY KEY AUTOINCREMENT,
    RoomId       INTEGER NOT NULL REFERENCES Rooms(Id) ON DELETE CASCADE,
    Model        TEXT    NOT NULL,
    Power        REAL    NOT NULL CHECK (Power >= 0),
    Type         TEXT    NOT NULL CHECK (Type IN ('Sensor', 'Actuator')),
    Accuracy     REAL    NULL,
    LoadCapacity REAL    NULL,
    PassportJson TEXT    NULL
);

CREATE TABLE IF NOT EXISTS TelemetryLogs (
    Id        INTEGER PRIMARY KEY AUTOINCREMENT,
    DeviceId  INTEGER NOT NULL REFERENCES Devices(Id) ON DELETE CASCADE,
    Reading   REAL    NOT NULL,
    Timestamp TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS IX_Devices_RoomId         ON Devices(RoomId);
CREATE INDEX IF NOT EXISTS IX_TelemetryLogs_DeviceId ON TelemetryLogs(DeviceId);
