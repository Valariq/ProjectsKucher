using System.Globalization;
using SmartHomeMasterConsole.Events;
using SmartHomeMasterConsole.Interfaces;

namespace SmartHomeMasterConsole.Models;

public abstract class Device : IExportable, IComparable<Device>, ICloneable
{
    protected const double StandbyFactor = 0.05;

    public const string ExportSeparator = ";";

    public const string ExportHeader = "Id;RoomId;Model;Type;Power;SerialNumber;Extra";

    protected bool _isActive;

    protected Device(int id, int roomId, string model, double power, DevicePassport? passport)
    {
        if (string.IsNullOrWhiteSpace(model))
            throw new ArgumentException("Модель устройства не может быть пустой.", nameof(model));
        if (double.IsNaN(power) || double.IsInfinity(power) || power < 0)
            throw new ArgumentOutOfRangeException(nameof(power), power, "Мощность должна быть неотрицательным числом.");

        Id = id;
        RoomId = roomId;
        Model = model.Trim();
        Power = power;
        Passport = passport ?? new DevicePassport();
        _isActive = true;
    }

    protected Device(Device source)
        : this(source.Id, source.RoomId, source.Model, source.Power, source.Passport.DeepCopy())
    {
        _isActive = source._isActive;
        LastReading = source.LastReading;
    }

    public int Id { get; private set; }
    public string Model { get; private set; }
    public double Power { get; private set; }
    public int RoomId { get; private set; }

    public DevicePassport Passport { get; private set; }

    public double? LastReading { get; private set; }

    public bool IsActive => _isActive;

    public abstract string Type { get; }

    public abstract string TypeDisplayName { get; }

    public string Title => $"«{Model}» #{Id}";

    public event EventHandler<DeviceEventArgs>? StatusChanged;

    protected virtual void OnStatusChanged(string message, bool isCritical = false) =>
        StatusChanged?.Invoke(this, new DeviceEventArgs(message, isCritical));

    public void TurnOn() => SetActive(true);

    public void TurnOff() => SetActive(false);

    public void Toggle() => SetActive(!_isActive);

    private void SetActive(bool value)
    {
        if (_isActive == value) return;
        _isActive = value;
        OnStatusChanged($"{Title}: {(value ? "включено" : "выключено")}");
    }

    public double RegisterReading(double rawValue)
    {
        double value = Math.Round(Passport.Calibration.Apply(rawValue), 2);
        LastReading = value;
        bool critical = IsReadingCritical(value);
        OnStatusChanged($"{Title}: показание {FormatReading(value)}{(critical ? " — КРИТИЧНО" : string.Empty)}", critical);
        return value;
    }

    internal void RestoreLastReading(double value) => LastReading = value;

    internal void AssignId(int id)
    {
        if (Id != 0) throw new InvalidOperationException($"Устройству уже назначен Id = {Id}.");
        Id = id;
    }

    public virtual string GetStatus() =>
        $"{TypeDisplayName} {Title}: {(_isActive ? "активен" : "отключён")}, " +
        $"потребление {CalculatePowerConsumption():F2} Вт";

    public abstract double CalculatePowerConsumption();

    public string GetDescription() => $"Устройство умного дома «{Model}» мощностью {Power:F1} Вт";

    protected virtual bool IsReadingCritical(double value) => false;

    protected virtual string FormatReading(double value) => value.ToString("F2", CultureInfo.CurrentCulture);

    string IExportable.GetExportData() => BuildExportData();

    protected virtual string BuildExportData() => string.Join(ExportSeparator,
        Id.ToString(CultureInfo.InvariantCulture),
        RoomId.ToString(CultureInfo.InvariantCulture),
        EscapeCsv(Model),
        Type,
        Power.ToString("0.###", CultureInfo.InvariantCulture),
        EscapeCsv(Passport.SerialNumber));

    protected static string EscapeCsv(string value) =>
        value.IndexOfAny(new[] { ';', '"', '\n' }) >= 0 ? "\"" + value.Replace("\"", "\"\"") + "\"" : value;

    public int CompareTo(Device? other)
    {
        if (other is null) return 1;
        int byPower = Power.CompareTo(other.Power);
        return byPower != 0 ? byPower : Id.CompareTo(other.Id);
    }

    public object Clone() => CreateDeepCopy();

    public Device DeepClone() => CreateDeepCopy();

    protected abstract Device CreateDeepCopy();

    public Device CloneAsNew(string modelSuffix = " (копия)")
    {
        Device copy = CreateDeepCopy();
        copy.Id = 0;
        copy.Model = Model + modelSuffix;
        copy.Passport.ServiceHistory.Add($"{DateTime.Now:dd.MM.yyyy HH:mm} — создан копированием прибора #{Id}");
        return copy;
    }

    public override string ToString() =>
        $"#{Id} {TypeDisplayName} «{Model}», {Power:F1} Вт, комната #{RoomId}, {(_isActive ? "вкл." : "выкл.")}";

    public override bool Equals(object? obj)
    {
        if (ReferenceEquals(this, obj)) return true;

        return obj is Device other
               && Id == other.Id
               && string.Equals(Model, other.Model, StringComparison.Ordinal);
    }

    public override int GetHashCode() => HashCode.Combine(Id, Model);
}
