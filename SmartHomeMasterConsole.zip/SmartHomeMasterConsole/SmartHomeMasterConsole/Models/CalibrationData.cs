namespace SmartHomeMasterConsole.Models;

public sealed class CalibrationData
{
    public double Factor { get; set; } = 1.0;
    public double Offset { get; set; }
    public DateTime CalibratedAt { get; set; }

    public double Apply(double rawValue) => rawValue * Factor + Offset;

    public CalibrationData DeepCopy() => new()
    {
        Factor = Factor,
        Offset = Offset,
        CalibratedAt = CalibratedAt,
    };

    public override string ToString() =>
        $"k = {Factor:0.000}, b = {Offset:+0.00;-0.00;0.00} (от {CalibratedAt:dd.MM.yyyy})";
}
