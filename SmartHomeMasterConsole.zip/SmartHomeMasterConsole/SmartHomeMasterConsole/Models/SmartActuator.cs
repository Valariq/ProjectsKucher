using System.Globalization;

namespace SmartHomeMasterConsole.Models;

public class SmartActuator : Device
{
    public const string TypeName = "Actuator";

    public const double OverloadPercent = 90.0;

    public SmartActuator(int id, int roomId, string model, double power, double loadCapacity, DevicePassport? passport = null)
        : base(id, roomId, model, power, passport)
    {
        if (double.IsNaN(loadCapacity) || loadCapacity <= 0)
            throw new ArgumentOutOfRangeException(nameof(loadCapacity), loadCapacity, "Допустимая нагрузка должна быть больше нуля.");
        LoadCapacity = loadCapacity;
    }

    protected SmartActuator(SmartActuator source)
        : base(source)
    {
        LoadCapacity = source.LoadCapacity;
    }

    public double LoadCapacity { get; private set; }

    public override string Type => TypeName;

    public override string TypeDisplayName => "Актуатор";

    public double LoadPercent => CalculatePowerConsumption() / LoadCapacity * 100.0;

    public bool IsOverloaded => _isActive && LoadPercent >= OverloadPercent;

    public override double CalculatePowerConsumption() => _isActive ? LastReading ?? Power : Power * StandbyFactor;

    public override string GetStatus() =>
        base.GetStatus() + $", нагрузка {LoadPercent:F0} % от {LoadCapacity:F0} Вт" + (IsOverloaded ? " — ПЕРЕГРУЗКА" : string.Empty);

    protected override bool IsReadingCritical(double value) => value >= LoadCapacity * OverloadPercent / 100.0;

    protected override string FormatReading(double value) => $"{value:F1} Вт ({value / LoadCapacity * 100:F0} % нагрузки)";

    protected override string BuildExportData() =>
        base.BuildExportData() + ExportSeparator + "LoadCapacity=" + LoadCapacity.ToString("0.###", CultureInfo.InvariantCulture);

    protected override Device CreateDeepCopy() => new SmartActuator(this);

    public override string ToString() => base.ToString() + $", нагрузка до {LoadCapacity:F0} Вт";
}
