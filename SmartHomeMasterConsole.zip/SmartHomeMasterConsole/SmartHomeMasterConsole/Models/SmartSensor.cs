using System.Globalization;

namespace SmartHomeMasterConsole.Models;

public class SmartSensor : Device
{
    public const string TypeName = "Sensor";

    public const double DegradedAccuracyLimit = 2.0;

    public SmartSensor(int id, int roomId, string model, double power, double accuracy, DevicePassport? passport = null)
        : base(id, roomId, model, power, passport)
    {
        if (double.IsNaN(accuracy) || accuracy < 0)
            throw new ArgumentOutOfRangeException(nameof(accuracy), accuracy, "Погрешность не может быть отрицательной.");
        Accuracy = accuracy;
    }

    protected SmartSensor(SmartSensor source)
        : base(source)
    {
        Accuracy = source.Accuracy;
    }

    public double Accuracy { get; private set; }

    public override string Type => TypeName;

    public override string TypeDisplayName => "Датчик";

    public bool IsAlarm => LastReading is double value && IsReadingCritical(value);

    public bool IsDegraded => Accuracy > DegradedAccuracyLimit;

    public override double CalculatePowerConsumption() => _isActive ? Power : Power * StandbyFactor;

    public override string GetStatus()
    {
        string status = base.GetStatus() + $", погрешность ±{Accuracy:F1} %";
        if (IsAlarm)
            status += $", ТРЕВОГА: {LastReading:F2} {Passport.Unit} > {Passport.SafeLimit:0.##}";
        else if (IsDegraded)
            status += ", требуется поверка";
        return status;
    }

    public new string GetDescription() =>
        $"Датчик «{Model}»: единица «{Passport.Unit}», порог {Passport.SafeLimit:0.##}, погрешность ±{Accuracy:F1} %";

    protected override bool IsReadingCritical(double value) => Passport.SafeLimit > 0 && value > Passport.SafeLimit;

    protected override string FormatReading(double value) => $"{value:F2} {Passport.Unit}".TrimEnd();

    protected override string BuildExportData() =>
        base.BuildExportData() + ExportSeparator + "Accuracy=" + Accuracy.ToString("0.###", CultureInfo.InvariantCulture);

    protected override Device CreateDeepCopy() => new SmartSensor(this);

    public override string ToString() => base.ToString() + $", ±{Accuracy:F1} %";
}
