namespace SmartHomeMasterConsole.Models;

public sealed class Room
{
    public Room(int id, string title, int floor)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Название комнаты не может быть пустым.", nameof(title));

        Id = id;
        Title = title.Trim();
        Floor = floor;
    }

    public int Id { get; private set; }
    public string Title { get; private set; }
    public int Floor { get; private set; }

    internal void AssignId(int id) => Id = id;

    public override string ToString() => $"{Title} (этаж {Floor})";
}
