namespace SmartHomeMasterConsole.Models;

public static class DeviceFactory
{
    public static Device Create(
        string type, int id, int roomId, string model, double power,
        double? accuracy, double? loadCapacity, DevicePassport? passport) => type switch
    {
        SmartSensor.TypeName => new SmartSensor(id, roomId, model, power, accuracy ?? 1.0, passport),
        SmartActuator.TypeName => new SmartActuator(id, roomId, model, power, loadCapacity ?? Math.Max(power, 1.0) * 1.25, passport),
        _ => throw new InvalidDataException($"Неизвестный тип устройства «{type}». Допустимо: Sensor, Actuator."),
    };
}
