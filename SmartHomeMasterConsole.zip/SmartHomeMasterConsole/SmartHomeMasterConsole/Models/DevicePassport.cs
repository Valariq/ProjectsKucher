namespace SmartHomeMasterConsole.Models;

public sealed class DevicePassport : ICloneable
{
    public string SerialNumber { get; set; } = "N/A";
    public string Manufacturer { get; set; } = "неизвестно";
    public DateTime CommissionedAt { get; set; } = DateTime.Today;

    public string Unit { get; set; } = string.Empty;

    public double SafeLimit { get; set; }

    public CalibrationData Calibration { get; set; } = new();

    public List<string> ServiceHistory { get; set; } = new();

    public DevicePassport DeepCopy() => new()
    {
        SerialNumber = SerialNumber,
        Manufacturer = Manufacturer,
        CommissionedAt = CommissionedAt,
        Unit = Unit,
        SafeLimit = SafeLimit,
        Calibration = Calibration.DeepCopy(),
        ServiceHistory = new List<string>(ServiceHistory),
    };

    object ICloneable.Clone() => DeepCopy();

    public override string ToString() =>
        $"S/N {SerialNumber}; {Manufacturer}; ед. «{Unit}», порог {SafeLimit:0.##}; " +
        $"калибровка {Calibration}; записей ТО: {ServiceHistory.Count}";
}
