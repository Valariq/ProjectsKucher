using System.Globalization;

namespace SmartHomeMasterConsole.Models;

public sealed class TelemetryLog
{
    public const string TimestampFormat = "yyyy-MM-dd HH:mm:ss";

    public TelemetryLog(int id, int deviceId, double reading, DateTime timestamp)
    {
        Id = id;
        DeviceId = deviceId;
        Reading = reading;
        Timestamp = timestamp;
    }

    public TelemetryLog(int deviceId, double reading, DateTime timestamp)
        : this(0, deviceId, reading, timestamp)
    {
    }

    public int Id { get; private set; }
    public int DeviceId { get; private set; }
    public double Reading { get; private set; }
    public DateTime Timestamp { get; private set; }

    public string TimestampText => Timestamp.ToString(TimestampFormat, CultureInfo.InvariantCulture);

    internal void AssignId(int id) => Id = id;

    public static DateTime ParseTimestamp(string text) =>
        DateTime.ParseExact(text, TimestampFormat, CultureInfo.InvariantCulture);

    public override string ToString() => $"#{Id}: прибор {DeviceId} = {Reading:F2} ({Timestamp:dd.MM HH:mm})";
}
