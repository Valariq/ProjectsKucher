using System.Text;
using SmartHomeMasterConsole.Dto;
using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Services;

public static class DeepCopyVerifier
{
    public static bool SharesNoReferences(Device original, Device clone) =>
        !ReferenceEquals(original, clone)
        && !ReferenceEquals(original.Passport, clone.Passport)
        && !ReferenceEquals(original.Passport.Calibration, clone.Passport.Calibration)
        && !ReferenceEquals(original.Passport.ServiceHistory, clone.Passport.ServiceHistory);

    public static DeepCopyReport Verify(Device original, Device clone)
    {
        var text = new StringBuilder();
        text.AppendLine($"Оригинал : {original}");
        text.AppendLine($"Копия    : {clone}");
        text.AppendLine($"Тип копии совпадает с типом оригинала: {clone.GetType() == original.GetType()} ({clone.GetType().Name})");
        text.AppendLine($"Equals(оригинал, копия)                 = {original.Equals(clone)}   (по Id и Model)");
        text.AppendLine($"ReferenceEquals(оригинал, копия)        = {ReferenceEquals(original, clone)}");
        text.AppendLine($"ReferenceEquals(Passport)               = {ReferenceEquals(original.Passport, clone.Passport)}");
        text.AppendLine($"ReferenceEquals(Passport.Calibration)   = {ReferenceEquals(original.Passport.Calibration, clone.Passport.Calibration)}");
        text.AppendLine($"ReferenceEquals(Passport.ServiceHistory)= {ReferenceEquals(original.Passport.ServiceHistory, clone.Passport.ServiceHistory)}");

        double offsetBefore = original.Passport.Calibration.Offset;
        double factorBefore = original.Passport.Calibration.Factor;
        string serialBefore = original.Passport.SerialNumber;
        int historyBefore = original.Passport.ServiceHistory.Count;

        clone.Passport.Calibration.Offset += 0.75;
        clone.Passport.Calibration.Factor = Math.Round(clone.Passport.Calibration.Factor * 1.01, 3);
        clone.Passport.SerialNumber += "-COPY";
        clone.Passport.ServiceHistory.Add($"{DateTime.Now:dd.MM.yyyy HH:mm} — перекалибровка копии");

        text.AppendLine();
        text.AppendLine("Изменяем паспорт КОПИИ: Offset += 0.75; Factor *= 1.01; S/N += \"-COPY\"; +1 запись ТО");
        text.AppendLine($"  оригинал: {original.Passport}");
        text.AppendLine($"  копия   : {clone.Passport}");

        bool originalUntouched =
            original.Passport.Calibration.Offset.Equals(offsetBefore)
            && original.Passport.Calibration.Factor.Equals(factorBefore)
            && original.Passport.SerialNumber == serialBefore
            && original.Passport.ServiceHistory.Count == historyBefore;

        bool isDeep = SharesNoReferences(original, clone) && originalUntouched;
        text.AppendLine();
        text.AppendLine(isDeep
            ? "ИТОГ: [OK] глубокая копия — изменения копии не затронули оригинал."
            : "ИТОГ: [ОШИБКА] поверхностная копия — оригинал изменился вместе с копией!");

        return new DeepCopyReport(isDeep, text.ToString());
    }
}
