using System.Collections.Concurrent;
using System.Diagnostics;
using SmartHomeMasterConsole.Data;
using SmartHomeMasterConsole.Dto;
using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Services;

public sealed class TelemetryPollingService
{
    private readonly TelemetryRepository _telemetry;
    private readonly RoomRepository _rooms;
    private readonly ConcurrentDictionary<int, string> _roomTitleCache = new();

    public TelemetryPollingService(TelemetryRepository telemetry, RoomRepository rooms)
    {
        _telemetry = telemetry ?? throw new ArgumentNullException(nameof(telemetry));
        _rooms = rooms ?? throw new ArgumentNullException(nameof(rooms));
    }

    public async Task<PollResult[]> PollAllAsync(
        IReadOnlyCollection<Device> devices, IProgress<int>? progress = null, CancellationToken cancellationToken = default)
    {
        int completed = 0;

        List<Task<PollResult>> tasks = devices.Select(async device =>
        {
            PollResult result = await PollDeviceAsync(device, cancellationToken).ConfigureAwait(false);
            progress?.Report(Interlocked.Increment(ref completed));
            return result;
        }).ToList();

        PollResult[] results = await Task.WhenAll(tasks).ConfigureAwait(false);

        List<TelemetryLog> logs = results
            .Select(result => new TelemetryLog(result.Device.Id, result.Reading, result.Timestamp))
            .ToList();
        await _telemetry.AddRangeAsync(logs, cancellationToken).ConfigureAwait(false);

        return results;
    }

    public async Task<PollResult> PollDeviceAsync(Device device, CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        await Task.Delay(TelemetrySimulator.NextLatencyMs(Random.Shared), cancellationToken).ConfigureAwait(false);

        double reading = device.RegisterReading(TelemetrySimulator.NextRawReading(device, Random.Shared));
        stopwatch.Stop();

        return new PollResult(device, reading, DateTime.Now, stopwatch.Elapsed, DeviceDelegates.IsCritical(device));
    }

    public ValueTask<string> GetRoomTitleAsync(int roomId, CancellationToken cancellationToken = default)
    {
        if (_roomTitleCache.TryGetValue(roomId, out string? cached))
            return new ValueTask<string>(cached);

        return new ValueTask<string>(LoadRoomTitleAsync(roomId, cancellationToken));
    }

    public int CachedRoomCount => _roomTitleCache.Count;

    public void ClearCache() => _roomTitleCache.Clear();

    private async Task<string> LoadRoomTitleAsync(int roomId, CancellationToken cancellationToken)
    {
        Room? room = await Task.Run(() => _rooms.FindByIdAsync(roomId, cancellationToken), cancellationToken).ConfigureAwait(false);
        string title = room?.Title ?? $"комната #{roomId} не найдена";
        _roomTitleCache[roomId] = title;
        return title;
    }
}
