using System.Text;
using SmartHomeMasterConsole.Dto;
using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Services;

public sealed class LinqAnalyticsService
{
    private readonly IReadOnlyList<Room> _rooms;
    private readonly IReadOnlyList<Device> _devices;
    private readonly IReadOnlyList<TelemetryLog> _logs;

    public LinqAnalyticsService(IReadOnlyList<Room> rooms, IReadOnlyList<Device> devices, IReadOnlyList<TelemetryLog> logs)
    {
        _rooms = rooms ?? throw new ArgumentNullException(nameof(rooms));
        _devices = devices ?? throw new ArgumentNullException(nameof(devices));
        _logs = logs ?? throw new ArgumentNullException(nameof(logs));
    }

    public List<DeviceReportDto> BuildDeviceReports() =>
        _devices
            .Join(_rooms,
                device => device.RoomId,
                room => room.Id,
                (device, room) => new { Device = device, Room = room })
            .GroupJoin(_logs,
                pair => pair.Device.Id,
                log => log.DeviceId,
                (pair, logs) => new { pair.Device, pair.Room, Readings = logs.ToList() })
            .Select(x => new DeviceReportDto
            {
                DeviceId = x.Device.Id,
                Model = x.Device.Model,
                Type = x.Device.Type,
                Power = x.Device.Power,
                RoomTitle = x.Room.Title,
                Floor = x.Room.Floor,
                ReadingsCount = x.Readings.Count,
                AverageReading = x.Readings.Count == 0 ? null : Math.Round(x.Readings.Average(log => log.Reading), 2),
                LastReadingAt = x.Readings.Count == 0 ? null : x.Readings.Max(log => log.Timestamp),
                IsCritical = DeviceDelegates.IsCritical(x.Device),
            })
            .ToList();

    public List<(Room Room, int DeviceCount)> CountDevicesPerRoom() =>
        _rooms
            .GroupJoin(_devices, room => room.Id, device => device.RoomId, (room, devices) => (Room: room, DeviceCount: devices.Count()))
            .OrderBy(x => x.Room.Floor)
            .ThenBy(x => x.Room.Title)
            .ToList();

    public static IEnumerable<DeviceReportDto> FilterAndSort(IEnumerable<DeviceReportDto> source, DeviceFilter filter)
    {
        IEnumerable<DeviceReportDto> query = source.Where(d => d.Power >= filter.MinPower);

        if (filter.Type is not null)
            query = query.Where(d => d.Type == filter.Type);
        if (filter.Floor is not null)
            query = query.Where(d => d.Floor == filter.Floor);
        if (!string.IsNullOrWhiteSpace(filter.SearchText))
        {
            string text = filter.SearchText.Trim();
            query = query.Where(d => d.Model.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0
                                     || d.RoomTitle.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0);
        }
        if (filter.OnlyCritical)
            query = query.Where(d => d.IsCritical);

        return query
            .OrderBy(d => d.Floor)
            .ThenByDescending(d => d.Power);
    }

    public static PagedResult<T> Paginate<T>(IEnumerable<T> source, int page, int pageSize)
    {
        if (pageSize <= 0) throw new ArgumentOutOfRangeException(nameof(pageSize), "Размер страницы должен быть больше нуля.");

        List<T> all = source.ToList();
        int totalPages = Math.Max(1, (all.Count + pageSize - 1) / pageSize);
        int current = Math.Min(Math.Max(page, 1), totalPages);

        List<T> items = all
            .Skip((current - 1) * pageSize)
            .Take(pageSize)
            .ToList();

        return new PagedResult<T>(items, current, pageSize, all.Count, totalPages);
    }

    public static List<RoomStatisticsDto> BuildRoomStatistics(IEnumerable<DeviceReportDto> reports) =>
        reports
            .GroupBy(d => d.RoomTitle)
            .Select(group => new RoomStatisticsDto
            {
                RoomTitle = group.Key,
                Floor = group.First().Floor,
                DeviceCount = group.Count(),
                TotalPower = Math.Round(group.Sum(d => d.Power), 1),
                AveragePower = Math.Round(group.Average(d => d.Power), 1),
                MaxPower = group.Max(d => d.Power),
                CriticalCount = group.Count(d => d.IsCritical),
                Models = group
                    .Select(d => d.Model)
                    .Distinct()
                    .Aggregate((accumulated, model) => accumulated + ", " + model),
            })
            .OrderBy(stat => stat.Floor)
            .ThenByDescending(stat => stat.TotalPower)
            .ToList();

    public static double TotalPower(IEnumerable<DeviceReportDto> reports) =>
        reports.Aggregate(0.0, (sum, d) => sum + d.Power);

    public RoomComparisonResult CompareRooms(int roomAId, int roomBId)
    {
        Room roomA = _rooms.FirstOrDefault(r => r.Id == roomAId) ?? throw new ArgumentException($"Комната #{roomAId} не найдена.", nameof(roomAId));
        Room roomB = _rooms.FirstOrDefault(r => r.Id == roomBId) ?? throw new ArgumentException($"Комната #{roomBId} не найдена.", nameof(roomBId));

        List<Device> inA = _devices.Where(d => d.RoomId == roomAId).ToList();
        List<Device> inB = _devices.Where(d => d.RoomId == roomBId).ToList();
        DeviceModelComparer byModel = DeviceModelComparer.Instance;

        return new RoomComparisonResult(
            roomA, roomB, inA.Count, inB.Count,
            Common: inA.Intersect(inB, byModel).ToList(),
            OnlyInA: inA.Except(inB, byModel).ToList(),
            OnlyInB: inB.Except(inA, byModel).ToList(),
            Union: inA.Union(inB, byModel).ToList());
    }

    public List<Device> FindDevicesWithoutTelemetry()
    {
        IEnumerable<Device> reporting = _logs
            .Select(log => log.DeviceId)
            .Distinct()
            .Join(_devices, id => id, device => device.Id, (_, device) => device);

        return _devices.Except(reporting).ToList();
    }

    public static List<Device> MergeRegistries(IEnumerable<Device> first, IEnumerable<Device> second) =>
        first.Union(second).ToList();

    public List<string> DescribeEqualityBasedSets(double heavyPowerLimit)
    {
        List<Device> silent = FindDevicesWithoutTelemetry();
        List<Device> clones = _devices.Select(d => d.DeepClone()).ToList();
        List<Device> merged = MergeRegistries(_devices, clones);
        List<Device> critical = _devices.ToList().FindAll(DeviceDelegates.IsCritical);
        List<Device> heavyAndCritical = critical.Intersect(_devices.Where(d => d.Power >= heavyPowerLimit)).ToList();

        return new List<string>
        {
            $"Except(все, с телеметрией) -> без показаний: {silent.Count}"
                + (silent.Count > 0 ? " (" + string.Join(", ", silent.Select(d => d.Model)) + ")" : string.Empty),
            $"Union(реестр {_devices.Count}, клоны {clones.Count}) = {merged.Count} — клоны равны оригиналам по Equals/GetHashCode",
            $"Intersect(критичные {critical.Count}, Power >= {heavyPowerLimit:0} Вт) = {heavyAndCritical.Count}"
                + (heavyAndCritical.Count > 0 ? " (" + string.Join(", ", heavyAndCritical.Select(d => d.Model)) + ")" : string.Empty),
        };
    }

    public QuantifierReport RunQuantifierChecks(double powerLimit)
    {
        bool anyCritical = _devices.Any(DeviceDelegates.IsCritical.Invoke);
        bool allLinked = _devices.All(d => _rooms.Any(r => r.Id == d.RoomId));
        bool allReporting = _devices.All(d => _logs.Any(l => l.DeviceId == d.Id));
        bool anyOverLimit = _devices.Any(d => d.Power > powerLimit);

        Device? firstOverLimit = _devices.FirstOrDefault(d => d.Power > powerLimit);
        Room? firstEmptyRoom = _rooms.FirstOrDefault(r => !_devices.Any(d => d.RoomId == r.Id));
        Device? missing = _devices.FirstOrDefault(d => d.Id == int.MaxValue);

        return new QuantifierReport(anyCritical, allLinked, allReporting, powerLimit, anyOverLimit, firstOverLimit, firstEmptyRoom, missing);
    }

    public string DemonstrateDeferredExecution()
    {
        var text = new StringBuilder();
        var source = new List<Device>(_devices);
        int predicateCalls = 0;

        IEnumerable<Device> deferred = source.Where(d =>
        {
            predicateCalls++;
            return d.Power >= 1000;
        });
        text.AppendLine($"1) IEnumerable<Device> deferred = source.Where(d => d.Power >= 1000);");
        text.AppendLine($"   вызовов предиката: {predicateCalls} — запрос только описан, ничего не выполнено");

        List<Device> snapshot = deferred.ToList();
        text.AppendLine($"2) List<Device> snapshot = deferred.ToList();");
        text.AppendLine($"   найдено {snapshot.Count}, вызовов предиката: {predicateCalls} — немедленная материализация (проход по {source.Count} элементам)");

        source.Add(new SmartActuator(0, 0, "Временный обогреватель 3 кВт", 3000, 3500));
        text.AppendLine("3) source.Add(новый прибор 3000 Вт)");

        int before = predicateCalls;
        int deferredCount = deferred.Count();
        text.AppendLine($"4) deferred.Count() = {deferredCount} — запрос выполнен ЗАНОВО (+{predicateCalls - before} вызовов) и видит новый прибор");
        text.AppendLine($"   snapshot.Count   = {snapshot.Count} — снимок ToList() не изменился");

        before = predicateCalls;
        bool any = deferred.Any();
        text.AppendLine($"5) deferred.Any() = {any} — остановился на первом совпадении (+{predicateCalls - before} вызовов из {source.Count})");

        text.AppendLine();
        text.AppendLine("Вывод: IEnumerable<T> хранит «рецепт» и выполняется при каждом перечислении (foreach, Count, Any, ToList);");
        text.AppendLine("ToList()/ToArray() выполняют запрос один раз и фиксируют результат.");
        return text.ToString();
    }
}
