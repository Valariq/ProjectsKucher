using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Services;

public static class TelemetrySimulator
{
    public static double NextRawReading(Device device, Random random) => device switch
    {
        SmartActuator actuator => actuator.Power * (0.55 + random.NextDouble() * 0.60),
        SmartSensor sensor when sensor.Passport.SafeLimit > 0 => sensor.Passport.SafeLimit * (0.35 + random.NextDouble() * 0.75),
        _ => random.NextDouble() * 100.0,
    };

    public static int NextLatencyMs(Random random) => random.Next(250, 1500);
}
