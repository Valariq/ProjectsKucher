using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Services;

public sealed class DeviceModelComparer : IEqualityComparer<Device>
{
    public static readonly DeviceModelComparer Instance = new();

    public bool Equals(Device? x, Device? y)
    {
        if (ReferenceEquals(x, y)) return true;
        if (x is null || y is null) return false;
        return string.Equals(x.Model, y.Model, StringComparison.OrdinalIgnoreCase) && x.Type == y.Type;
    }

    public int GetHashCode(Device obj) =>
        HashCode.Combine(StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Model), obj.Type);
}
