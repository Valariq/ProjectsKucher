using SmartHomeMasterConsole.Models;

namespace SmartHomeMasterConsole.Services;

public static class DeviceDelegates
{
    public static readonly Predicate<Device> IsCritical = device => device switch
    {
        SmartActuator actuator => actuator.IsOverloaded,
        SmartSensor sensor => sensor.IsAlarm || sensor.IsDegraded,
        _ => false,
    };

    public static readonly Func<Device, double> CurrentConsumption = device => device.CalculatePowerConsumption();

    public static readonly Func<Device, double> DailyEnergyKWh = device => device.CalculatePowerConsumption() * 24 / 1000.0;

    public static Func<double, bool> CreatePowerThresholdChecker(double thresholdWatts, Action<string>? onExceeded = null)
    {
        double threshold = thresholdWatts;
        int exceededCount = 0;

        return power =>
        {
            if (power <= threshold) return false;

            exceededCount++;
            onExceeded?.Invoke($"  превышение #{exceededCount}: {power:F1} Вт > {threshold:F1} Вт");
            return true;
        };
    }
}
